# QuoteVerse Security Specification

## 1. Data Invariants
1. **Owner-Only PII Isolation**: A user document at `/users/{userId}` contains `email` and personal preferences and may only be read, created, updated, or deleted by the verified owner (`request.auth.uid == userId && request.auth.token.email_verified == true`).
2. **Parent Existence & Relational Sync (Master Gate)**: Subcollection records under `/users/{userId}/history/{historyId}`, `/favorites/{favoriteId}`, `/collections/{collectionId}`, `/notes/{noteId}`, and `/activity/{activityId}` require the parent `/users/{userId}` document to exist and `incoming().userId == request.auth.uid`.
3. **Deduplicated Quote Ownership**: Canonical quotes in `/quotes/{quoteId}` require `createdBy == request.auth.uid` and strictly validate `quoteText` (3..1000 chars), `author` (1..160 chars), and `category` (1..60 chars).
4. **Immutable Ownership & Creation Timestamps**: `userId`, `uid`, `createdBy`, `createdAt`, and `generatedAt` may never be reassigned on update, and all creation/update timestamps must equal `request.time`.
5. **No Shadow Fields**: Every collection enforces `keys().hasAll(...) && keys().hasOnly(...)` on create and `affectedKeys().hasOnly(...)` on update.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated Read on User Profile**: `get /users/alice` with `auth == null` -> `PERMISSION_DENIED`.
2. **Cross-User PII Read**: `get /users/alice` with `auth.uid == 'bob'` -> `PERMISSION_DENIED`.
3. **Unverified Email Write**: `create /users/bob` with `email_verified == false` -> `PERMISSION_DENIED`.
4. **Shadow Admin Escalation Field**: `create /users/bob` including `isAdmin: true` -> `PERMISSION_DENIED`.
5. **Client-Spoofed Timestamp**: `create /users/bob/history/h1` with `generatedAt: "2020-01-01"` instead of `request.time` -> `PERMISSION_DENIED`.
6. **Oversized ID Poisoning**: `create /users/bob/history/<200-char-invalid-id!>` -> `PERMISSION_DENIED`.
7. **Identity Spoofing in Subcollection**: `create /users/bob/favorites/f1` with `userId: "alice"` -> `PERMISSION_DENIED`.
8. **1MB Resource Exhaustion String**: `create /quotes/q1` with 20,000-character `quoteText` -> `PERMISSION_DENIED`.
9. **Blanket List Scraping**: `list /quotes` by `bob` returning records where `createdBy != 'bob'` -> `PERMISSION_DENIED`.
10. **Immutable Field Mutation**: `update /users/bob/favorites/f1` attempting to modify `createdAt` or `userId` -> `PERMISSION_DENIED`.
11. **Invalid Enum Value**: `create /users/bob/activity/a1` with `activityType: "drop_table"` -> `PERMISSION_DENIED`.
12. **Orphaned Subcollection Write**: `create /users/bob/collections/c1` when `/users/bob` does not exist -> `PERMISSION_DENIED`.
