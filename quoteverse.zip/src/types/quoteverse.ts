export type NavSection =
  | 'dashboard'
  | 'generator'
  | 'history'
  | 'favorites'
  | 'categories'
  | 'analytics'
  | 'settings'
  | 'profile';

export type MoodOption =
  | 'Motivated'
  | 'Happy'
  | 'Confident'
  | 'Focused'
  | 'Hopeful'
  | 'Stressed'
  | 'Sad';

export type ApiProviderOption =
  | 'auto'
  | 'zenquotes'
  | 'dummyjson'
  | 'quotable'
  | 'curated';

export type ActivityType =
  | 'generate'
  | 'favorite'
  | 'unfavorite'
  | 'export'
  | 'studio'
  | 'task_sync'
  | 'chat_share'
  | 'note_save'
  | 'ai_ground';

export interface Quote {
  id: string;
  quoteText: string;
  author: string;
  category: string;
  source: string;
  externalApiId: string;
  createdAt: string;
}

export interface HistoryEntry {
  id: string;
  userId: string;
  quoteId: string;
  quoteText: string;
  author: string;
  category: string;
  source: string;
  mood: string;
  isFavorite: boolean;
  generatedAt: string;
}

export interface FavoriteEntry {
  id: string;
  userId: string;
  quoteId: string;
  quoteText: string;
  author: string;
  category: string;
  source: string;
  collectionId: string;
  createdAt: string;
}

export interface QuoteCollection {
  id: string;
  userId: string;
  name: string;
  description: string;
  color: string;
  createdAt: string;
  updatedAt: string;
}

export interface QuoteNote {
  id: string;
  userId: string;
  quoteId: string;
  title: string;
  body: string;
  quoteText: string;
  author: string;
  createdAt: string;
  updatedAt: string;
}

export interface ActivityEntry {
  id: string;
  userId: string;
  activityType: ActivityType;
  category: string;
  mood: string;
  details: string;
  createdAt: string;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL: string;
  theme: 'light' | 'dark';
  dailyInspirationEnabled: boolean;
  preferredCategory: string;
  preferredApiProvider: ApiProviderOption;
  createdAt: string;
  updatedAt: string;
}

export interface CategoryInfo {
  id: string;
  name: string;
  description: string;
  quoteCount: number;
  featuredQuote: {
    quoteText: string;
    author: string;
  };
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface GroundedQuoteContext {
  summary: string;
  historicalContext: string;
  reflectionPrompt: string;
  sources: GroundingSource[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedQuote?: {
    quoteText: string;
    author: string;
    category: string;
  };
  sources?: GroundingSource[];
}

export interface AnalyticsSummary {
  totalGenerated: number;
  totalFavorites: number;
  uniqueCategories: number;
  totalNotes: number;
  weeklySeries: { day: string; date: string; generated: number; favorites: number }[];
  monthlySeries: { week: string; generated: number; favorites: number }[];
  categoryBreakdown: { category: string; count: number }[];
  moodBreakdown: { mood: string; count: number }[];
}
