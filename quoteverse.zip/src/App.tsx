import { useCallback, useEffect, useMemo, useState } from 'react';
import type { User } from 'firebase/auth';
import { AiSageDrawer } from './components/AiSageDrawer.tsx';
import { AnalyticsView } from './components/AnalyticsView.tsx';
import { CategoriesView } from './components/CategoriesView.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { FavoritesView } from './components/FavoritesView.tsx';
import { GeneratorView } from './components/GeneratorView.tsx';
import { HistoryView } from './components/HistoryView.tsx';
import { ProfileWorkspaceView } from './components/ProfileWorkspaceView.tsx';
import { QuoteStudioModal } from './components/QuoteStudioModal.tsx';
import { SettingsView } from './components/SettingsView.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { TopBar } from './components/TopBar.tsx';
import { WorkspaceActionModal } from './components/WorkspaceActionModal.tsx';
import { signInWithGoogle, signOutGoogle, subscribeToAuth } from './lib/firebase.ts';
import {
  fetchAiMoodRecommendationApi,
  fetchDailyQuoteApi,
  fetchGroundedQuoteContextApi,
  fetchRandomQuoteApi,
} from './services/apiClient.ts';
import {
  addFavoriteToFirestore,
  assignFavoriteCollectionFirestore,
  createCollectionFirestore,
  deleteCollectionFirestore,
  deleteHistoryFromFirestore,
  deleteNoteFirestore,
  ensureUserProfile,
  loadGuestPreferences,
  loadGuestState,
  logUserActivity,
  migrateGuestHistoryToFirestore,
  removeFavoriteFromFirestore,
  saveGeneratedQuoteToFirestore,
  saveGuestPreferences,
  saveGuestState,
  saveNoteFirestore,
  subscribeUserCollections,
  updateUserPreferences,
} from './services/firestoreService.ts';
import type {
  ActivityEntry,
  ActivityType,
  ApiProviderOption,
  FavoriteEntry,
  GroundedQuoteContext,
  HistoryEntry,
  MoodOption,
  NavSection,
  Quote,
  QuoteCollection,
  QuoteNote,
  UserProfile,
} from './types/quoteverse.ts';
import { buildCanonicalQuoteId, computeAnalyticsSummary } from './utils/quoteLogic.ts';

interface ModalQuoteRef {
  quoteId: string;
  quoteText: string;
  author: string;
  category: string;
}

function QuoteVerseShell() {
  const initialPrefs = useMemo(() => loadGuestPreferences(), []);
  const initialGuest = useMemo(() => loadGuestState(), []);

  // Navigation & layout state
  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Preferences state
  const [theme, setTheme] = useState<'light' | 'dark'>(initialPrefs.theme);
  const [dailyInspirationEnabled, setDailyInspirationEnabled] = useState<boolean>(
    initialPrefs.dailyInspirationEnabled
  );
  const [preferredCategory, setPreferredCategory] = useState<string>(
    initialPrefs.preferredCategory
  );
  const [preferredApiProvider, setPreferredApiProvider] = useState<ApiProviderOption>(
    initialPrefs.preferredApiProvider
  );

  // Auth & Profile state
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [hasWorkspaceToken, setHasWorkspaceToken] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);

  // Persistent Data state
  const [history, setHistory] = useState<HistoryEntry[]>(initialGuest.history);
  const [favorites, setFavorites] = useState<FavoriteEntry[]>(initialGuest.favorites);
  const [collections, setCollections] = useState<QuoteCollection[]>(initialGuest.collections);
  const [notes, setNotes] = useState<QuoteNote[]>(initialGuest.notes);
  const [activity, setActivity] = useState<ActivityEntry[]>(initialGuest.activity);

  // Daily Quote & Generator state
  const [dailyQuote, setDailyQuote] = useState<Quote | null>(null);
  const [dailyQuoteLoading, setDailyQuoteLoading] = useState(true);

  const [currentQuote, setCurrentQuote] = useState<Quote | null>(() => {
    const first = initialGuest.history[0];
    if (!first) return null;
    return {
      id: first.quoteId,
      quoteText: first.quoteText,
      author: first.author,
      category: first.category,
      source: first.source,
      externalApiId: first.quoteId,
      createdAt: first.generatedAt,
    };
  });
  const [currentMood, setCurrentMood] = useState<MoodOption>('Motivated');
  const [selectedCategory, setSelectedCategory] = useState<string>(
    initialPrefs.preferredCategory || 'All'
  );
  const [selectedProvider, setSelectedProvider] = useState<ApiProviderOption>(
    initialPrefs.preferredApiProvider || 'auto'
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [isAiRecommending, setIsAiRecommending] = useState(false);
  const [fallbackNotice, setFallbackNotice] = useState<string | null>(null);
  const [generatorError, setGeneratorError] = useState<string | null>(null);
  const [aiReason, setAiReason] = useState<string | null>(null);
  const [groundedContext, setGroundedContext] = useState<GroundedQuoteContext | null>(null);
  const [isGrounding, setIsGrounding] = useState(false);

  // Modals & Drawers
  const [aiDrawerOpen, setAiDrawerOpen] = useState(false);
  const [studioQuote, setStudioQuote] = useState<ModalQuoteRef | null>(null);
  const [workspaceQuote, setWorkspaceQuote] = useState<ModalQuoteRef | null>(null);

  // Sync Tailwind dark class on root html element
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  // Fetch Quote of the Day on mount
  useEffect(() => {
    let active = true;
    setDailyQuoteLoading(true);
    fetchDailyQuoteApi()
      .then((res) => {
        if (!active) return;
        setDailyQuote(res.quote);
      })
      .catch(() => {
        // Non-blocking; card handles null gracefully
      })
      .finally(() => {
        if (active) setDailyQuoteLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  // Optional Daily Inspiration browser notification when enabled and permitted
  useEffect(() => {
    if (!dailyInspirationEnabled || !dailyQuote) return;
    if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
    const todayKey = `quoteverse_notified_${new Date().toISOString().slice(0, 10)}`;
    try {
      if (window.sessionStorage.getItem(todayKey)) return;
      window.sessionStorage.setItem(todayKey, '1');
      new Notification('QuoteVerse — Quote of the Day', {
        body: `"${dailyQuote.quoteText}" — ${dailyQuote.author}`,
      });
    } catch {
      // Notification constructor unavailable in restricted iframe
    }
  }, [dailyInspirationEnabled, dailyQuote]);

  // Subscribe to Firebase Auth & Firestore collections
  useEffect(() => {
    let unsubFirestore: (() => void) | null = null;
    let cancelled = false;

    const unsubAuth = subscribeToAuth(async (user, workspaceTokenActive) => {
      if (unsubFirestore) {
        unsubFirestore();
        unsubFirestore = null;
      }

      setAuthUser(user);
      setHasWorkspaceToken(workspaceTokenActive);

      if (!user) {
        setProfile(null);
        const guest = loadGuestState();
        const prefs = loadGuestPreferences();
        setHistory(guest.history);
        setFavorites(guest.favorites);
        setCollections(guest.collections);
        setNotes(guest.notes);
        setActivity(guest.activity);
        setTheme(prefs.theme);
        setDailyInspirationEnabled(prefs.dailyInspirationEnabled);
        setPreferredCategory(prefs.preferredCategory);
        setPreferredApiProvider(prefs.preferredApiProvider);
        return;
      }

      try {
        const ensured = await ensureUserProfile(user);
        if (cancelled) return;
        setProfile(ensured);
        setTheme(ensured.theme);
        setDailyInspirationEnabled(ensured.dailyInspirationEnabled);
        setPreferredCategory(ensured.preferredCategory);
        setPreferredApiProvider(ensured.preferredApiProvider);
        setSelectedCategory(ensured.preferredCategory || 'All');
        setSelectedProvider(ensured.preferredApiProvider || 'auto');

        unsubFirestore = subscribeUserCollections(user.uid, {
          onHistory: (items) => setHistory(items),
          onFavorites: (items) => setFavorites(items),
          onCollections: (items) => setCollections(items),
          onNotes: (items) => setNotes(items),
          onActivity: (items) => setActivity(items),
          onError: (err) => console.error('Firestore listener warning:', err),
        });
      } catch (err) {
        console.error('Failed to initialize authenticated profile:', err);
      }
    });

    return () => {
      cancelled = true;
      unsubAuth();
      if (unsubFirestore) unsubFirestore();
    };
  }, []);

  const recordGuestActivity = useCallback(
    (type: ActivityType, category: string, mood: string, details: string) => {
      const entry: ActivityEntry = {
        id: `act_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        userId: 'guest',
        activityType: type,
        category,
        mood,
        details,
        createdAt: new Date().toISOString(),
      };
      setActivity((prev) => {
        const next = [entry, ...prev].slice(0, 60);
        saveGuestState({ activity: next });
        return next;
      });
    },
    []
  );

  const logActivity = useCallback(
    async (type: ActivityType, category: string, mood: string, details: string) => {
      if (authUser) {
        await logUserActivity(authUser.uid, type, category, mood, details).catch(() => {});
      } else {
        recordGuestActivity(type, category, mood, details);
      }
    },
    [authUser, recordGuestActivity]
  );

  const isFavorite = useCallback(
    (quoteId: string) => favorites.some((f) => f.quoteId === quoteId),
    [favorites]
  );

  const analytics = useMemo(
    () => computeAnalyticsSummary(history, favorites, activity, notes),
    [history, favorites, activity, notes]
  );

  const persistNewQuote = useCallback(
    async (quote: Quote, mood: string) => {
      if (authUser) {
        await saveGeneratedQuoteToFirestore(authUser.uid, quote, mood);
        return;
      }
      const canonicalId = buildCanonicalQuoteId(quote.quoteText, quote.author);
      const now = new Date().toISOString();
      const newEntry: HistoryEntry = {
        id: `hist_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        userId: 'guest',
        quoteId: canonicalId,
        quoteText: quote.quoteText,
        author: quote.author,
        category: quote.category,
        source: quote.source,
        mood: mood || 'General',
        isFavorite: favorites.some((f) => f.quoteId === canonicalId),
        generatedAt: now,
      };
      setHistory((prev) => {
        const next = [newEntry, ...prev];
        saveGuestState({ history: next });
        return next;
      });
      recordGuestActivity('generate', quote.category, mood, `Generated quote by ${quote.author}`);
    },
    [authUser, favorites, recordGuestActivity]
  );

  const handleGenerateRandom = useCallback(
    async (overrideCategory?: string) => {
      const targetCategory = overrideCategory ?? selectedCategory;
      setIsGenerating(true);
      setGeneratorError(null);
      setFallbackNotice(null);
      setAiReason(null);
      setGroundedContext(null);

      try {
        const excludeIds = history.slice(0, 15).map((h) => h.quoteId);
        const result = await fetchRandomQuoteApi({
          category: targetCategory,
          provider: selectedProvider,
          excludeIds,
        });

        setCurrentQuote(result.quote);
        if (result.fallbackUsed) {
          setFallbackNotice(
            result.providerError ||
              'External API was temporarily slow or unavailable; served from QuoteVerse curated archive.'
          );
        }
        await persistNewQuote(result.quote, currentMood);
      } catch (err) {
        setGeneratorError(
          err instanceof Error
            ? err.message
            : 'Unable to fetch a new quote right now. Please try again.'
        );
      } finally {
        setIsGenerating(false);
      }
    },
    [selectedCategory, selectedProvider, history, currentMood, persistNewQuote]
  );

  const handleQuickGenerate = useCallback(() => {
    setActiveSection('generator');
    void handleGenerateRandom();
  }, [handleGenerateRandom]);

  const handleGenerateFromCategory = useCallback(
    (categoryName: string) => {
      setSelectedCategory(categoryName);
      setActiveSection('generator');
      void handleGenerateRandom(categoryName);
    },
    [handleGenerateRandom]
  );

  const handleAiRecommend = useCallback(
    async (interest: string) => {
      setIsAiRecommending(true);
      setGeneratorError(null);
      setFallbackNotice(null);
      setGroundedContext(null);

      try {
        const res = await fetchAiMoodRecommendationApi({
          mood: currentMood,
          interest: interest.trim() || undefined,
        });
        setCurrentQuote(res.quote);
        setAiReason(res.whyItFits);
        await persistNewQuote(res.quote, currentMood);
      } catch (err: unknown) {
        const msg =
          (err as { response?: { data?: { error?: string } } })?.response?.data?.error ||
          (err instanceof Error ? err.message : 'AI recommendation failed.');
        setGeneratorError(msg);
      } finally {
        setIsAiRecommending(false);
      }
    },
    [currentMood, persistNewQuote]
  );

  const handleGroundQuote = useCallback(
    async (target: { quoteId?: string; id?: string; quoteText: string; author: string; category: string; source?: string; timestamp?: string; generatedAt?: string }) => {
      const normalizedQuote: Quote = {
        id: target.quoteId || target.id || buildCanonicalQuoteId(target.quoteText, target.author),
        quoteText: target.quoteText,
        author: target.author,
        category: target.category,
        source: target.source || 'QuoteVerse Archive',
        externalApiId: target.quoteId || target.id || '',
        createdAt: target.generatedAt || target.timestamp || new Date().toISOString(),
      };
      setCurrentQuote(normalizedQuote);
      setActiveSection('generator');
      setIsGrounding(true);
      setGroundedContext(null);
      setGeneratorError(null);

      try {
        const ctx = await fetchGroundedQuoteContextApi({
          quoteText: normalizedQuote.quoteText,
          author: normalizedQuote.author,
        });
        setGroundedContext(ctx);
        await logActivity('ai_ground', normalizedQuote.category, currentMood, `Verified quote by ${normalizedQuote.author}`);
      } catch (err: unknown) {
        const msg =
          (err as { response?: { data?: { error?: string } } })?.response?.data?.error ||
          (err instanceof Error ? err.message : 'Could not load grounded quote context.');
        setGeneratorError(msg);
      } finally {
        setIsGrounding(false);
      }
    },
    [currentMood, logActivity]
  );

  const handleToggleFavorite = useCallback(
    async (item: {
      quoteId?: string;
      id: string;
      quoteText: string;
      author: string;
      category: string;
      source: string;
    }) => {
      const canonicalId =
        item.quoteId || buildCanonicalQuoteId(item.quoteText, item.author);
      const alreadyFav = favorites.some((f) => f.quoteId === canonicalId);
      const matchingHistoryIds = history
        .filter((h) => h.quoteId === canonicalId)
        .map((h) => h.id);

      if (authUser) {
        if (alreadyFav) {
          await removeFavoriteFromFirestore(authUser.uid, canonicalId, matchingHistoryIds);
        } else {
          await addFavoriteToFirestore(
            authUser.uid,
            {
              quoteId: canonicalId,
              quoteText: item.quoteText,
              author: item.author,
              category: item.category,
              source: item.source,
            },
            '',
            matchingHistoryIds
          );
        }
        return;
      }

      if (alreadyFav) {
        setFavorites((prev) => {
          const next = prev.filter((f) => f.quoteId !== canonicalId);
          saveGuestState({ favorites: next });
          return next;
        });
        setHistory((prev) => {
          const next = prev.map((h) =>
            h.quoteId === canonicalId ? { ...h, isFavorite: false } : h
          );
          saveGuestState({ history: next });
          return next;
        });
        recordGuestActivity('unfavorite', item.category, '', `Removed favorite: ${item.author}`);
      } else {
        const newFav: FavoriteEntry = {
          id: canonicalId,
          userId: 'guest',
          quoteId: canonicalId,
          quoteText: item.quoteText,
          author: item.author,
          category: item.category,
          source: item.source,
          collectionId: '',
          createdAt: new Date().toISOString(),
        };
        setFavorites((prev) => {
          const next = [newFav, ...prev];
          saveGuestState({ favorites: next });
          return next;
        });
        setHistory((prev) => {
          const next = prev.map((h) =>
            h.quoteId === canonicalId ? { ...h, isFavorite: true } : h
          );
          saveGuestState({ history: next });
          return next;
        });
        recordGuestActivity('favorite', item.category, '', `Saved favorite: ${item.author}`);
      }
    },
    [authUser, favorites, history, recordGuestActivity]
  );

  const handleRemoveFavoriteByQuoteId = useCallback(
    async (quoteId: string) => {
      const existing = favorites.find((f) => f.quoteId === quoteId);
      if (!existing) return;
      await handleToggleFavorite(existing);
    },
    [favorites, handleToggleFavorite]
  );

  const handleDeleteHistory = useCallback(
    async (historyId: string) => {
      if (authUser) {
        await deleteHistoryFromFirestore(authUser.uid, historyId);
        return;
      }
      setHistory((prev) => {
        const next = prev.filter((h) => h.id !== historyId);
        saveGuestState({ history: next });
        return next;
      });
    },
    [authUser]
  );

  const handleAssignCollection = useCallback(
    async (favoriteId: string, collectionId: string) => {
      if (authUser) {
        await assignFavoriteCollectionFirestore(authUser.uid, favoriteId, collectionId);
        return;
      }
      setFavorites((prev) => {
        const next = prev.map((f) => (f.id === favoriteId ? { ...f, collectionId } : f));
        saveGuestState({ favorites: next });
        return next;
      });
    },
    [authUser]
  );

  const handleCreateCollection = useCallback(
    async (name: string, description: string, color: string) => {
      if (authUser) {
        await createCollectionFirestore(authUser.uid, name, description, color);
        return;
      }
      const now = new Date().toISOString();
      const created: QuoteCollection = {
        id: `col_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        userId: 'guest',
        name,
        description,
        color,
        createdAt: now,
        updatedAt: now,
      };
      setCollections((prev) => {
        const next = [created, ...prev];
        saveGuestState({ collections: next });
        return next;
      });
    },
    [authUser]
  );

  const handleDeleteCollection = useCallback(
    async (collectionId: string) => {
      if (authUser) {
        await deleteCollectionFirestore(authUser.uid, collectionId);
        return;
      }
      setCollections((prev) => {
        const next = prev.filter((c) => c.id !== collectionId);
        saveGuestState({ collections: next });
        return next;
      });
      setFavorites((prev) => {
        const next = prev.map((f) => (f.collectionId === collectionId ? { ...f, collectionId: '' } : f));
        saveGuestState({ favorites: next });
        return next;
      });
    },
    [authUser]
  );

  const handleSaveNote = useCallback(
    async (note: {
      quoteId: string;
      title: string;
      body: string;
      quoteText: string;
      author: string;
    }) => {
      if (authUser) {
        await saveNoteFirestore(authUser.uid, note);
        return;
      }
      const now = new Date().toISOString();
      const created: QuoteNote = {
        id: `note_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        userId: 'guest',
        quoteId: note.quoteId,
        title: note.title,
        body: note.body,
        quoteText: note.quoteText,
        author: note.author,
        createdAt: now,
        updatedAt: now,
      };
      setNotes((prev) => {
        const next = [created, ...prev];
        saveGuestState({ notes: next });
        return next;
      });
      recordGuestActivity('note_save', '', '', `Saved note: ${note.title}`);
    },
    [authUser, recordGuestActivity]
  );

  const handleDeleteNote = useCallback(
    async (noteId: string) => {
      if (authUser) {
        await deleteNoteFirestore(authUser.uid, noteId);
        return;
      }
      setNotes((prev) => {
        const next = prev.filter((n) => n.id !== noteId);
        saveGuestState({ notes: next });
        return next;
      });
    },
    [authUser]
  );

  const handleUpdateSettings = useCallback(
    async (updates: {
      theme?: 'light' | 'dark';
      dailyInspirationEnabled?: boolean;
      preferredCategory?: string;
      preferredApiProvider?: ApiProviderOption;
    }) => {
      const nextTheme = updates.theme ?? theme;
      const nextDaily = updates.dailyInspirationEnabled ?? dailyInspirationEnabled;
      const nextCategory = updates.preferredCategory ?? preferredCategory;
      const nextProvider = updates.preferredApiProvider ?? preferredApiProvider;

      if (updates.theme !== undefined) setTheme(updates.theme);
      if (updates.dailyInspirationEnabled !== undefined) {
        setDailyInspirationEnabled(updates.dailyInspirationEnabled);
      }
      if (updates.preferredCategory !== undefined) {
        setPreferredCategory(updates.preferredCategory);
        setSelectedCategory(updates.preferredCategory);
      }
      if (updates.preferredApiProvider !== undefined) {
        setPreferredApiProvider(updates.preferredApiProvider);
        setSelectedProvider(updates.preferredApiProvider);
      }

      if (authUser) {
        await updateUserPreferences(authUser.uid, updates).catch(() => {});
      } else {
        saveGuestPreferences({
          theme: nextTheme,
          dailyInspirationEnabled: nextDaily,
          preferredCategory: nextCategory,
          preferredApiProvider: nextProvider,
        });
      }
    },
    [authUser, theme, dailyInspirationEnabled, preferredCategory, preferredApiProvider]
  );

  const handleGoogleSignIn = useCallback(async () => {
    const { accessToken } = await signInWithGoogle();
    if (accessToken) {
      setHasWorkspaceToken(true);
    }
  }, []);

  const handleSignOut = useCallback(async () => {
    await signOutGoogle();
  }, []);

  const handleMigrateGuest = useCallback(async () => {
    if (!authUser) return 0;
    return migrateGuestHistoryToFirestore(authUser.uid);
  }, [authUser]);

  const userDisplayName = authUser
    ? profile?.displayName || authUser.displayName || 'Reader'
    : 'Guest Reader';
  const userEmail = authUser ? profile?.email || authUser.email || '' : '';
  const userPhotoUrl = authUser ? profile?.photoURL || authUser.photoURL || '' : '';

  return (
    <div className="min-h-screen flex bg-[#F8FAFC] dark:bg-[#0F172A] text-[#1E293B] dark:text-[#F8FAFC]">
      <Sidebar
        activeSection={activeSection}
        onSelect={(section) => setActiveSection(section)}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed((c) => !c)}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        userDisplayName={userDisplayName}
        userEmail={userEmail}
        userPhotoUrl={userPhotoUrl}
        isAuthenticated={Boolean(authUser)}
        historyCount={history.length}
        favoritesCount={favorites.length}
      />

      <div className="flex-1 min-w-0 flex flex-col">
        <TopBar
          activeSection={activeSection}
          searchQuery={searchQuery}
          onSearchChange={(value) => setSearchQuery(value)}
          onSearchSubmit={() => setActiveSection('history')}
          theme={theme}
          onToggleTheme={() =>
            void handleUpdateSettings({ theme: theme === 'dark' ? 'light' : 'dark' })
          }
          onOpenAiChat={() => setAiDrawerOpen(true)}
          onQuickGenerate={handleQuickGenerate}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {activeSection === 'dashboard' && (
            <DashboardView
              userName={userDisplayName}
              dailyQuote={dailyQuote}
              dailyQuoteLoading={dailyQuoteLoading}
              analytics={analytics}
              recentHistory={history}
              isFavorite={isFavorite}
              onToggleFavorite={(entry) => void handleToggleFavorite(entry)}
              onNavigate={(sec) => setActiveSection(sec)}
              onQuickGenerate={handleQuickGenerate}
              onOpenStudio={(q) => setStudioQuote(q)}
            />
          )}

          {activeSection === 'generator' && (
            <GeneratorView
              currentQuote={currentQuote}
              currentMood={currentMood}
              selectedCategory={selectedCategory}
              selectedProvider={selectedProvider}
              isGenerating={isGenerating}
              fallbackNotice={fallbackNotice}
              errorMsg={generatorError}
              aiReason={aiReason}
              groundedContext={groundedContext}
              isGrounding={isGrounding}
              isAiRecommending={isAiRecommending}
              isFavorite={isFavorite}
              onChangeMood={(m) => setCurrentMood(m)}
              onChangeCategory={(c) => setSelectedCategory(c)}
              onChangeProvider={(p) => setSelectedProvider(p)}
              onGenerateRandom={() => void handleGenerateRandom()}
              onAiRecommend={(interest) => void handleAiRecommend(interest)}
              onGroundCurrent={() => {
                if (currentQuote) void handleGroundQuote(currentQuote);
              }}
              onToggleFavorite={(q) =>
                void handleToggleFavorite({
                  id: q.id,
                  quoteId: q.id,
                  quoteText: q.quoteText,
                  author: q.author,
                  category: q.category,
                  source: q.source,
                })
              }
              onOpenStudio={(q) =>
                setStudioQuote({
                  quoteId: q.id,
                  quoteText: q.quoteText,
                  author: q.author,
                  category: q.category,
                })
              }
              onOpenWorkspace={(q) =>
                setWorkspaceQuote({
                  quoteId: q.id,
                  quoteText: q.quoteText,
                  author: q.author,
                  category: q.category,
                })
              }
            />
          )}

          {activeSection === 'history' && (
            <HistoryView
              entries={history}
              searchQuery={searchQuery}
              onSearchChange={(val) => setSearchQuery(val)}
              isFavorite={isFavorite}
              onToggleFavorite={(entry) => void handleToggleFavorite(entry)}
              onDeleteHistory={(id) => void handleDeleteHistory(id)}
              onOpenStudio={(entry) =>
                setStudioQuote({
                  quoteId: entry.quoteId,
                  quoteText: entry.quoteText,
                  author: entry.author,
                  category: entry.category,
                })
              }
              onOpenWorkspace={(entry) =>
                setWorkspaceQuote({
                  quoteId: entry.quoteId,
                  quoteText: entry.quoteText,
                  author: entry.author,
                  category: entry.category,
                })
              }
              onGroundQuote={(entry) => void handleGroundQuote(entry)}
              onGoToGenerator={() => setActiveSection('generator')}
              onLogExport={(format) =>
                void logActivity('export', '', '', `Exported quote history as ${format}`)
              }
            />
          )}

          {activeSection === 'favorites' && (
            <FavoritesView
              favorites={favorites}
              collections={collections}
              onRemoveFavorite={(qId) => void handleRemoveFavoriteByQuoteId(qId)}
              onAssignCollection={(favId, colId) => void handleAssignCollection(favId, colId)}
              onCreateCollection={(name, desc, color) =>
                void handleCreateCollection(name, desc, color)
              }
              onDeleteCollection={(colId) => void handleDeleteCollection(colId)}
              onOpenStudio={(fav) =>
                setStudioQuote({
                  quoteId: fav.quoteId,
                  quoteText: fav.quoteText,
                  author: fav.author,
                  category: fav.category,
                })
              }
              onOpenWorkspace={(fav) =>
                setWorkspaceQuote({
                  quoteId: fav.quoteId,
                  quoteText: fav.quoteText,
                  author: fav.author,
                  category: fav.category,
                })
              }
              onGoToGenerator={() => setActiveSection('generator')}
            />
          )}

          {activeSection === 'categories' && (
            <CategoriesView onGenerateFromCategory={handleGenerateFromCategory} />
          )}

          {activeSection === 'analytics' && (
            <AnalyticsView analytics={analytics} activity={activity} />
          )}

          {activeSection === 'settings' && (
            <SettingsView
              theme={theme}
              dailyInspirationEnabled={dailyInspirationEnabled}
              preferredCategory={preferredCategory}
              preferredApiProvider={preferredApiProvider}
              onUpdateSettings={(updates) => void handleUpdateSettings(updates)}
            />
          )}

          {activeSection === 'profile' && (
            <ProfileWorkspaceView
              isAuthenticated={Boolean(authUser)}
              hasWorkspaceToken={hasWorkspaceToken}
              profile={profile}
              notes={notes}
              historyCount={history.length}
              favoritesCount={favorites.length}
              onGoogleSignIn={handleGoogleSignIn}
              onSignOut={handleSignOut}
              onMigrateGuest={handleMigrateGuest}
              onDeleteNote={(noteId) => void handleDeleteNote(noteId)}
            />
          )}
        </main>
      </div>

      {studioQuote && (
        <QuoteStudioModal
          quote={studioQuote}
          onClose={() => setStudioQuote(null)}
          onDownloaded={() =>
            void logActivity(
              'studio',
              studioQuote.category,
              '',
              `Downloaded quote poster for ${studioQuote.author}`
            )
          }
        />
      )}

      {workspaceQuote && (
        <WorkspaceActionModal
          quote={workspaceQuote}
          isAuthenticated={Boolean(authUser)}
          onSignIn={handleGoogleSignIn}
          onSaveNote={handleSaveNote}
          onLogWorkspaceAction={(type, details) =>
            void logActivity(type, workspaceQuote.category, '', details)
          }
          onClose={() => setWorkspaceQuote(null)}
        />
      )}

      <AiSageDrawer
        open={aiDrawerOpen}
        onClose={() => setAiDrawerOpen(false)}
        activeQuote={currentQuote || dailyQuote}
      />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <QuoteVerseShell />
    </ErrorBoundary>
  );
}
