import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  AlertCircle,
  ExternalLink,
  Globe,
  RefreshCw,
  Sparkles,
  Wand2,
} from 'lucide-react';
import { ALL_CATEGORIES, ALL_MOODS } from '../data/quotesCatalog.ts';
import type {
  ApiProviderOption,
  GroundedQuoteContext,
  MoodOption,
  Quote,
} from '../types/quoteverse.ts';
import { QuoteCard } from './QuoteCard.tsx';

interface GeneratorViewProps {
  currentQuote: Quote | null;
  currentMood: MoodOption;
  selectedCategory: string;
  selectedProvider: ApiProviderOption;
  isGenerating: boolean;
  fallbackNotice: string | null;
  errorMsg: string | null;
  aiReason: string | null;
  groundedContext: GroundedQuoteContext | null;
  isGrounding: boolean;
  isAiRecommending: boolean;
  isFavorite: (quoteId: string) => boolean;
  onChangeMood: (mood: MoodOption) => void;
  onChangeCategory: (category: string) => void;
  onChangeProvider: (provider: ApiProviderOption) => void;
  onGenerateRandom: () => void;
  onAiRecommend: (interest: string) => void;
  onGroundCurrent: () => void;
  onToggleFavorite: (quote: Quote) => void;
  onOpenStudio: (quote: Quote) => void;
  onOpenWorkspace: (quote: Quote) => void;
}

export const GeneratorView: React.FC<GeneratorViewProps> = ({
  currentQuote,
  currentMood,
  selectedCategory,
  selectedProvider,
  isGenerating,
  fallbackNotice,
  errorMsg,
  aiReason,
  groundedContext,
  isGrounding,
  isAiRecommending,
  isFavorite,
  onChangeMood,
  onChangeCategory,
  onChangeProvider,
  onGenerateRandom,
  onAiRecommend,
  onGroundCurrent,
  onToggleFavorite,
  onOpenStudio,
  onOpenWorkspace,
}) => {
  const [interestInput, setInterestInput] = useState('');

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
              Random Quote Generator
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Every generated quote is automatically preserved in your persistent history.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onGenerateRandom}
              disabled={isGenerating}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#4338CA] hover:bg-[#3730A3] disabled:opacity-60 text-white text-sm font-medium transition-colors whitespace-nowrap shrink-0"
            >
              <RefreshCw className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
              <span>{isGenerating ? 'Fetching Quote...' : currentQuote ? 'Generate Another Quote' : 'Generate Random Quote'}</span>
            </button>
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-xs font-medium text-slate-600 dark:text-slate-300">
            Select Current Mood
          </label>
          <div className="flex flex-wrap gap-2">
            {ALL_MOODS.map((item) => {
              const active = currentMood === item.mood;
              return (
                <button
                  key={item.mood}
                  type="button"
                  onClick={() => onChangeMood(item.mood)}
                  title={item.description}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-[#4338CA] text-white border-[#4338CA]'
                      : 'bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
                  }`}
                >
                  {item.mood}
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 pt-2 border-t border-slate-100 dark:border-slate-700/60">
          <div className="md:col-span-3 space-y-1.5">
            <label htmlFor="gen-category" className="block text-xs font-medium text-slate-600 dark:text-slate-300">
              Category Filter
            </label>
            <select
              id="gen-category"
              value={selectedCategory}
              onChange={(e) => onChangeCategory(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4338CA]"
            >
              <option value="All">All Categories</option>
              {ALL_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-3 space-y-1.5">
            <label htmlFor="gen-provider" className="block text-xs font-medium text-slate-600 dark:text-slate-300">
              API Provider
            </label>
            <select
              id="gen-provider"
              value={selectedProvider}
              onChange={(e) => onChangeProvider(e.target.value as ApiProviderOption)}
              className="w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4338CA]"
            >
              <option value="auto">Auto (Multi-Provider)</option>
              <option value="dummyjson">DummyJSON Quotes API</option>
              <option value="zenquotes">ZenQuotes API</option>
              <option value="quotable">Quotable API</option>
              <option value="curated">QuoteVerse Archive</option>
            </select>
          </div>

          <div className="md:col-span-6 space-y-1.5">
            <label htmlFor="ai-interest" className="block text-xs font-medium text-slate-600 dark:text-slate-300">
              AI Mood Recommendation (Optional topic or focus)
            </label>
            <div className="flex items-center gap-2">
              <input
                id="ai-interest"
                type="text"
                value={interestInput}
                onChange={(e) => setInterestInput(e.target.value)}
                placeholder="e.g., stoicism, launching a product, deep focus..."
                className="flex-1 min-w-0 px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#4338CA]"
              />
              <button
                type="button"
                onClick={() => onAiRecommend(interestInput)}
                disabled={isAiRecommending || isGenerating}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-60 text-white text-sm font-medium transition-colors whitespace-nowrap shrink-0"
              >
                <Wand2 className="w-4 h-4" />
                <span>{isAiRecommending ? 'Curating...' : 'AI Recommend'}</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {errorMsg && (
        <div
          role="alert"
          className="flex items-start gap-3 p-4 rounded-xl bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/30 text-rose-800 dark:text-rose-200 text-sm"
        >
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <span>{errorMsg}</span>
        </div>
      )}

      {fallbackNotice && (
        <div className="flex items-start gap-3 p-3.5 rounded-xl bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30 text-amber-800 dark:text-amber-200 text-xs">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{fallbackNotice}</span>
        </div>
      )}

      <section aria-live="polite" className="min-h-[220px]">
        {isGenerating && !currentQuote ? (
          <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-8 space-y-4 animate-pulse">
            <div className="h-4 w-48 bg-slate-200 dark:bg-slate-700 rounded" />
            <div className="h-7 w-full bg-slate-200 dark:bg-slate-700 rounded" />
            <div className="h-7 w-4/5 bg-slate-200 dark:bg-slate-700 rounded" />
            <div className="h-4 w-32 bg-slate-200 dark:bg-slate-700 rounded" />
          </div>
        ) : currentQuote ? (
          <AnimatePresence mode="wait">
            <motion.div
              key={currentQuote.id + currentQuote.createdAt}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
              className="space-y-4"
            >
              {aiReason && (
                <div className="px-4 py-3 rounded-xl bg-[#8B5CF6]/10 border border-[#8B5CF6]/25 text-xs sm:text-sm text-slate-800 dark:text-slate-200 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#8B5CF6] shrink-0" />
                  <span>{aiReason}</span>
                </div>
              )}

              <QuoteCard
                quote={{
                  id: currentQuote.id,
                  quoteId: currentQuote.id,
                  quoteText: currentQuote.quoteText,
                  author: currentQuote.author,
                  category: currentQuote.category,
                  source: currentQuote.source,
                  timestamp: currentQuote.createdAt,
                  mood: currentMood,
                  isFavorite: isFavorite(currentQuote.id),
                }}
                onToggleFavorite={() => onToggleFavorite(currentQuote)}
                onOpenStudio={() => onOpenStudio(currentQuote)}
                onOpenWorkspace={() => onOpenWorkspace(currentQuote)}
                onGroundWithAi={onGroundCurrent}
              />
            </motion.div>
          </AnimatePresence>
        ) : (
          <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-10 text-center space-y-4">
            <p className="font-serif text-xl text-slate-800 dark:text-slate-200">
              Ready to discover your next quote
            </p>
            <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">
              Choose a mood or category above, or generate a random quote from external APIs.
            </p>
            <button
              type="button"
              onClick={onGenerateRandom}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#4338CA] text-white text-sm font-medium hover:bg-[#3730A3]"
            >
              <Sparkles className="w-4 h-4" />
              Generate Quote
            </button>
          </div>
        )}
      </section>

      {(isGrounding || groundedContext) && (
        <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
            <Globe className="w-4 h-4 text-[#4338CA] dark:text-indigo-300" />
            <h3>Google Search Grounded Attribution &amp; Context</h3>
          </div>

          {isGrounding ? (
            <div className="space-y-2 animate-pulse">
              <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-full" />
              <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-5/6" />
              <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded w-2/3" />
            </div>
          ) : groundedContext ? (
            <div className="space-y-4">
              <div className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                {groundedContext.summary}
              </div>

              {groundedContext.sources.length > 0 && (
                <div className="pt-3 border-t border-slate-100 dark:border-slate-700/60 space-y-2">
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                    Verified Web Sources
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {groundedContext.sources.map((src) => (
                      <a
                        key={src.uri}
                        href={src.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-[#4338CA] dark:text-indigo-300 hover:underline max-w-xs truncate"
                      >
                        <ExternalLink className="w-3 h-3 shrink-0" />
                        <span className="truncate">{src.title}</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : null}
        </section>
      )}
    </div>
  );
};
