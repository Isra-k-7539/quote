import React, { useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import type { ActivityEntry, AnalyticsSummary } from '../types/quoteverse.ts';

interface AnalyticsViewProps {
  analytics: AnalyticsSummary;
  activity: ActivityEntry[];
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ analytics, activity }) => {
  const [range, setRange] = useState<'weekly' | 'monthly'>('weekly');
  const chartData =
    range === 'weekly'
      ? analytics.weeklySeries.map((d) => ({
          label: d.day,
          generated: d.generated,
          favorites: d.favorites,
        }))
      : analytics.monthlySeries.map((m) => ({
          label: m.week,
          generated: m.generated,
          favorites: m.favorites,
        }));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
            Reading &amp; Curation Analytics
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Track daily, weekly, and monthly quote discovery velocity, top categories, and mood patterns.
          </p>
        </div>

        <div className="inline-flex p-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 self-start">
          <button
            type="button"
            onClick={() => setRange('weekly')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              range === 'weekly'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            Last 7 Days
          </button>
          <button
            type="button"
            onClick={() => setRange('monthly')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              range === 'monthly'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            4-Week Monthly
          </button>
        </div>
      </div>

      {/* Main Trend Chart */}
      <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-semibold text-slate-900 dark:text-white">
            {range === 'weekly' ? 'Daily Quote Velocity' : 'Monthly Weekly Comparison'}
          </h3>
          <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
            {analytics.totalGenerated} total generated · {analytics.totalFavorites} favorited
          </span>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData} margin={{ top: 10, right: 16, left: -16, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#94A3B8" strokeOpacity={0.2} />
              <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#64748B' }} axisLine={false} tickLine={false} />
              <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: '#64748B' }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#FFFFFF',
                  borderRadius: '8px',
                  border: '1px solid #CBD5E1',
                  fontSize: '12px',
                  color: '#1E293B',
                }}
                labelStyle={{ color: '#0F172A', fontWeight: 600 }}
              />
              <Line
                type="monotone"
                dataKey="generated"
                name="Quotes Generated"
                stroke="#4338CA"
                strokeWidth={2.5}
                dot={{ r: 4, fill: '#4338CA' }}
              />
              <Line
                type="monotone"
                dataKey="favorites"
                name="Favorites Saved"
                stroke="#F59E0B"
                strokeWidth={2.5}
                dot={{ r: 4, fill: '#F59E0B' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
          <h3 className="text-base font-semibold text-slate-900 dark:text-white">
            Category Distribution
          </h3>
          <div className="h-64 w-full">
            {analytics.categoryBreakdown.length === 0 ? (
              <div className="h-full flex items-center justify-center text-sm text-slate-500">
                No category records yet.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={analytics.categoryBreakdown} margin={{ top: 8, right: 12, left: -16, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#94A3B8" strokeOpacity={0.2} />
                  <XAxis
                    dataKey="category"
                    tick={{ fontSize: 11, fill: '#64748B' }}
                    angle={-20}
                    textAnchor="end"
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#64748B' }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#FFFFFF',
                      borderRadius: '8px',
                      border: '1px solid #CBD5E1',
                      fontSize: '12px',
                      color: '#1E293B',
                    }}
                    labelStyle={{ color: '#0F172A', fontWeight: 600 }}
                  />
                  <Bar dataKey="count" name="Count" fill="#4338CA" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </section>

        <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
          <h3 className="text-base font-semibold text-slate-900 dark:text-white">
            Mood Resonance Breakdown
          </h3>
          {analytics.moodBreakdown.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-sm text-slate-500">
              Select moods when generating quotes to see mood insights.
            </div>
          ) : (
            <div className="space-y-3 pt-2">
              {analytics.moodBreakdown.map((item) => {
                const max = Math.max(...analytics.moodBreakdown.map((m) => m.count), 1);
                const pct = Math.round((item.count / max) * 100);
                return (
                  <div key={item.mood} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-slate-700 dark:text-slate-200">{item.mood}</span>
                      <span className="font-mono tabular-nums text-slate-500 dark:text-slate-400">
                        {item.count}
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[#8B5CF6]"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>

      {/* Activity Feed */}
      <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-3">
        <h3 className="text-base font-semibold text-slate-900 dark:text-white">
          Recent Activity Ledger
        </h3>
        {activity.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Activity events are recorded as you generate quotes, create posters, export archives, and sync with Workspace.
          </p>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-700/60">
            {activity.slice(0, 8).map((act) => (
              <div key={act.id} className="py-2.5 flex items-center justify-between gap-4 text-xs">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="font-mono text-[#4338CA] dark:text-indigo-300 shrink-0">
                    {act.activityType}
                  </span>
                  <span className="text-slate-400">·</span>
                  <span className="text-slate-700 dark:text-slate-300 truncate">
                    {act.details}
                  </span>
                </div>
                <time className="font-mono tabular-nums text-slate-400 shrink-0">
                  {new Date(act.createdAt).toLocaleDateString()}
                </time>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
