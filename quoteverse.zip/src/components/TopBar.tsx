import React from 'react';
import { Menu, MessageSquareQuote, Moon, Search, Sparkles, Sun } from 'lucide-react';
import type { NavSection } from '../types/quoteverse.ts';

interface TopBarProps {
  activeSection: NavSection;
  searchQuery: string;
  onSearchChange: (value: string) => void;
  onSearchSubmit: () => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  onOpenAiChat: () => void;
  onQuickGenerate: () => void;
  onOpenMobileMenu: () => void;
}

const SECTION_LABELS: Record<NavSection, string> = {
  dashboard: 'Dashboard',
  generator: 'Generate Quote',
  history: 'Quote History',
  favorites: 'Favorites',
  categories: 'Explore Categories',
  analytics: 'Analytics',
  settings: 'Settings',
  profile: 'User Profile',
};

export const TopBar: React.FC<TopBarProps> = ({
  activeSection,
  searchQuery,
  onSearchChange,
  onSearchSubmit,
  theme,
  onToggleTheme,
  onOpenAiChat,
  onQuickGenerate,
  onOpenMobileMenu,
}) => {
  return (
    <header className="sticky top-0 z-30 h-16 bg-white/95 dark:bg-[#0F172A]/95 backdrop-blur-sm border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 flex items-center justify-between gap-4">
      {/* Left: Mobile trigger + Breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          aria-label="Open navigation menu"
          className="lg:hidden p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2 text-sm min-w-0">
          <span className="hidden sm:inline text-slate-400 dark:text-slate-500 whitespace-nowrap">
            QuoteVerse
          </span>
          <span className="hidden sm:inline text-slate-300 dark:text-slate-700">/</span>
          <h1 className="font-semibold text-slate-900 dark:text-white truncate">
            {SECTION_LABELS[activeSection]}
          </h1>
        </div>
      </div>

      {/* Center: Global Search */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          onSearchSubmit();
        }}
        className="hidden md:flex items-center flex-1 max-w-md"
      >
        <div className="relative w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search quotes, authors, or categories..."
            aria-label="Global quote search"
            className="w-full pl-9 pr-3 py-1.5 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#4338CA]"
          />
        </div>
      </form>

      {/* Right: Theme + AI Sage + Primary Action */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={onToggleTheme}
          aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        <button
          type="button"
          onClick={onOpenAiChat}
          className="inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0"
        >
          <MessageSquareQuote className="w-4 h-4 text-[#8B5CF6]" />
          <span className="hidden sm:inline">Literary Sage</span>
        </button>

        <button
          type="button"
          onClick={onQuickGenerate}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#4338CA] hover:bg-[#3730A3] text-white text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0"
        >
          <Sparkles className="w-4 h-4" />
          <span>New Quote</span>
        </button>
      </div>
    </header>
  );
};
