import React, { useEffect, useRef, useState } from 'react';
import { ExternalLink, MessageSquareQuote, Send, X } from 'lucide-react';
import { sendAiChatMessageApi } from '../services/apiClient.ts';
import type { ChatMessage, Quote } from '../types/quoteverse.ts';

interface AiSageDrawerProps {
  open: boolean;
  onClose: () => void;
  activeQuote: Quote | null;
}

const STARTER_PROMPTS = [
  'Interpret the active quote in everyday life',
  'Recommend 2 Stoic quotes for calm focus',
  'Compare Seneca and Marcus Aurelius on resilience',
];

export const AiSageDrawer: React.FC<AiSageDrawerProps> = ({
  open,
  onClose,
  activeQuote,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'sage-welcome',
      role: 'assistant',
      text: 'Welcome to the QuoteVerse Literary Sage. Ask me to unpack a quote’s historical context, compare philosophers, or curate a quote for how you feel today.',
      timestamp: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, open]);

  if (!open) return null;

  const sendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || sending) return;

    const userMsg: ChatMessage = {
      id: `u_${Date.now()}`,
      role: 'user',
      text: trimmed,
      timestamp: new Date().toISOString(),
    };

    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    setInput('');
    setSending(true);
    setError(null);

    try {
      const res = await sendAiChatMessageApi({
        message: trimmed,
        history: nextHistory
          .filter((m) => m.id !== 'sage-welcome')
          .slice(0, -1)
          .map((m) => ({ role: m.role, text: m.text })),
        activeQuote: activeQuote
          ? {
              quoteText: activeQuote.quoteText,
              author: activeQuote.author,
              category: activeQuote.category,
            }
          : null,
      });

      setMessages((prev) => [
        ...prev,
        {
          id: `a_${Date.now()}`,
          role: 'assistant',
          text: res.reply,
          timestamp: new Date().toISOString(),
          sources: res.sources,
        },
      ]);
    } catch (err: unknown) {
      const errText =
        (err as { response?: { data?: { error?: string } } })?.response?.data?.error ||
        (err instanceof Error ? err.message : 'Unable to reach Literary Sage right now.');
      setError(errText);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/40 backdrop-blur-xs">
      <aside
        aria-label="QuoteVerse Literary Sage Chat"
        className="w-full max-w-md bg-white dark:bg-[#0F172A] border-l border-slate-200 dark:border-slate-800 h-full flex flex-col"
      >
        {/* Header */}
        <div className="h-16 px-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <MessageSquareQuote className="w-5 h-5 text-[#8B5CF6] shrink-0" />
            <div className="min-w-0">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                Literary Sage
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                Multi-turn reflection &amp; quote attribution
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Literary Sage chat"
            className="p-2 rounded-lg text-slate-400 hover:text-slate-800 dark:hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Active Quote Banner */}
        {activeQuote && (
          <div className="px-5 py-3 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 text-xs">
            <p className="text-slate-500 dark:text-slate-400 mb-0.5">Active Quote Context</p>
            <p className="font-serif text-slate-800 dark:text-slate-200 line-clamp-2">
              “{activeQuote.quoteText}” — {activeQuote.author}
            </p>
          </div>
        )}

        {/* Messages Thread */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[88%] rounded-xl px-4 py-3 text-sm leading-relaxed whitespace-pre-line ${
                  msg.role === 'user'
                    ? 'bg-[#4338CA] text-white'
                    : 'bg-slate-100 dark:bg-[#1E293B] text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700'
                }`}
              >
                {msg.text}

                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-3 pt-2 border-t border-slate-200/70 dark:border-slate-700 space-y-1">
                    <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                      Sources
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {msg.sources.slice(0, 3).map((s) => (
                        <a
                          key={s.uri}
                          href={s.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-[11px] text-[#4338CA] dark:text-indigo-300 hover:underline"
                        >
                          <ExternalLink className="w-3 h-3" />
                          <span className="truncate max-w-[160px]">{s.title}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}

          {sending && (
            <div className="flex items-start">
              <div className="px-4 py-3 rounded-xl bg-slate-100 dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700 text-xs text-slate-500 dark:text-slate-400">
                Sage is reflecting...
              </div>
            </div>
          )}

          {error && (
            <div role="alert" className="p-3 rounded-lg bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/30 text-xs text-rose-700 dark:text-rose-200">
              {error}
            </div>
          )}
        </div>

        {/* Starter Chips */}
        {messages.length <= 2 && (
          <div className="px-5 pb-2 flex flex-wrap gap-1.5">
            {STARTER_PROMPTS.map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => sendMessage(p)}
                className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-[11px] text-slate-700 dark:text-slate-300 text-left"
              >
                {p}
              </button>
            ))}
          </div>
        )}

        {/* Composer */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            sendMessage(input);
          }}
          className="p-4 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2 shrink-0"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask Literary Sage..."
            aria-label="Message Literary Sage"
            className="flex-1 min-w-0 px-3.5 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4338CA]"
          />
          <button
            type="submit"
            disabled={sending || !input.trim()}
            aria-label="Send message"
            className="p-2.5 rounded-lg bg-[#4338CA] hover:bg-[#3730A3] disabled:opacity-50 text-white"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </aside>
    </div>
  );
};
