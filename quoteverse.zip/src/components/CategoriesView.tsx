import React, { useEffect, useState } from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { getCategoryCatalog } from '../data/quotesCatalog.ts';
import { fetchCategoriesApi, fetchCategoryQuotesApi } from '../services/apiClient.ts';
import type { CategoryInfo, Quote } from '../types/quoteverse.ts';

interface CategoriesViewProps {
  onGenerateFromCategory: (category: string) => void;
}

export const CategoriesView: React.FC<CategoriesViewProps> = ({ onGenerateFromCategory }) => {
  const [categories, setCategories] = useState<CategoryInfo[]>(() => getCategoryCatalog());
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [categoryQuotes, setCategoryQuotes] = useState<Quote[]>([]);
  const [loadingQuotes, setLoadingQuotes] = useState(false);

  useEffect(() => {
    fetchCategoriesApi()
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) setCategories(data);
      })
      .catch(() => {
        // Fallback already seeded from getCategoryCatalog
      });
  }, []);

  const handleInspectCategory = async (categoryName: string) => {
    setSelectedCategory(categoryName);
    setLoadingQuotes(true);
    try {
      const quotes = await fetchCategoryQuotesApi(categoryName);
      setCategoryQuotes(quotes);
    } catch {
      setCategoryQuotes([]);
    } finally {
      setLoadingQuotes(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
            Explore 14 Curated Categories
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Select a theme to preview curated entries or launch a live random quote generation.
          </p>
        </div>
        {selectedCategory && (
          <button
            type="button"
            onClick={() => onGenerateFromCategory(selectedCategory)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#4338CA] hover:bg-[#3730A3] text-white text-sm font-medium whitespace-nowrap shrink-0"
          >
            <Sparkles className="w-4 h-4" />
            Generate {selectedCategory} Quote
          </button>
        )}
      </div>

      {/* Selected Category Preview Drawer */}
      {selectedCategory && (
        <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between gap-4">
            <h3 className="text-base font-semibold text-slate-900 dark:text-white">
              {selectedCategory} Highlights
            </h3>
            <button
              type="button"
              onClick={() => setSelectedCategory(null)}
              className="text-xs text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white"
            >
              Close Preview
            </button>
          </div>

          {loadingQuotes ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-pulse">
              <div className="h-24 rounded-lg bg-slate-100 dark:bg-slate-800" />
              <div className="h-24 rounded-lg bg-slate-100 dark:bg-slate-800" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {categoryQuotes.map((q) => (
                <div
                  key={q.id}
                  className="p-4 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700/60 space-y-2"
                >
                  <p className="font-serif text-sm text-slate-900 dark:text-slate-100">
                    “{q.quoteText}”
                  </p>
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                    — {q.author}
                  </p>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* 14 Category Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.name;
          return (
            <div
              key={cat.id}
              className={`bg-white dark:bg-[#1E293B] border rounded-xl p-5 flex flex-col justify-between gap-4 transition-colors ${
                isSelected
                  ? 'border-[#4338CA] dark:border-indigo-400'
                  : 'border-slate-200 dark:border-slate-700/80 hover:border-slate-300 dark:hover:border-slate-600'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                    {cat.name}
                  </h3>
                  <span className="text-xs font-mono tabular-nums text-slate-400">
                    {cat.quoteCount}
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  {cat.description}
                </p>
                <p className="font-serif text-xs italic text-slate-700 dark:text-slate-300 pt-1 line-clamp-2">
                  “{cat.featuredQuote.quoteText}”
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => handleInspectCategory(cat.name)}
                  className="text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
                >
                  Preview Quotes
                </button>
                <button
                  type="button"
                  onClick={() => onGenerateFromCategory(cat.name)}
                  className="inline-flex items-center gap-1 text-xs font-medium text-[#4338CA] dark:text-indigo-300 hover:underline whitespace-nowrap shrink-0"
                >
                  <span>Generate</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
