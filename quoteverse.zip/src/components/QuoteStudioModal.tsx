import React, { useEffect, useRef, useState } from 'react';
import { Download, X } from 'lucide-react';

interface QuoteStudioModalProps {
  quote: {
    quoteId: string;
    quoteText: string;
    author: string;
    category: string;
  };
  onClose: () => void;
  onDownloaded: () => void;
}

type StudioPreset = 'editorial-photo' | 'indigo-ink' | 'midnight-slate' | 'warm-parchment';
type StudioFont = 'Fraunces' | 'Plus Jakarta Sans' | 'JetBrains Mono';
type AspectPreset = '1:1' | '4:5' | '16:9';

const BACKDROPS: { id: StudioPreset; label: string; image?: string; bg: string; fg: string; accent: string }[] = [
  {
    id: 'editorial-photo',
    label: 'Library Light',
    image: '/src/assets/images/quoteverse_editorial_backdrop_1795431221192.jpg',
    bg: '#0F172A',
    fg: '#FFFFFF',
    accent: '#F59E0B',
  },
  {
    id: 'indigo-ink',
    label: 'Indigo Wash',
    image: '/src/assets/images/quoteverse_indigo_abstract_1795431220935.jpg',
    bg: '#1E1B4B',
    fg: '#FFFFFF',
    accent: '#F59E0B',
  },
  {
    id: 'midnight-slate',
    label: 'Deep Indigo',
    bg: '#0F172A',
    fg: '#F8FAFC',
    accent: '#8B5CF6',
  },
  {
    id: 'warm-parchment',
    label: 'Ivory Paper',
    bg: '#F8FAFC',
    fg: '#1E293B',
    accent: '#4338CA',
  },
];

export const QuoteStudioModal: React.FC<QuoteStudioModalProps> = ({
  quote,
  onClose,
  onDownloaded,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [preset, setPreset] = useState<StudioPreset>('indigo-ink');
  const [fontFamily, setFontFamily] = useState<StudioFont>('Fraunces');
  const [aspect, setAspect] = useState<AspectPreset>('1:1');

  const dimensions = aspect === '1:1' ? { w: 1080, h: 1080 } : aspect === '4:5' ? { w: 1080, h: 1350 } : { w: 1280, h: 720 };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const active = BACKDROPS.find((b) => b.id === preset) ?? BACKDROPS[0];
    let cancelled = false;

    const drawTextAndOverlay = () => {
      if (cancelled) return;
      if (active.image) {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.62)';
        ctx.fillRect(0, 0, dimensions.w, dimensions.h);
      }

      const padding = Math.round(dimensions.w * 0.1);
      ctx.fillStyle = active.accent;
      ctx.font = `600 ${Math.round(dimensions.w * 0.024)}px "Plus Jakarta Sans", sans-serif`;
      ctx.fillText(quote.category.toUpperCase(), padding, padding + 20);

      // Wrap quote text
      const fontSize = Math.round(dimensions.w * (quote.quoteText.length > 140 ? 0.04 : 0.048));
      ctx.fillStyle = active.fg;
      ctx.font = `500 ${fontSize}px "${fontFamily}", serif`;

      const maxWidth = dimensions.w - padding * 2;
      const words = `“${quote.quoteText}”`.split(' ');
      const lines: string[] = [];
      let current = '';

      for (const word of words) {
        const test = current ? `${current} ${word}` : word;
        if (ctx.measureText(test).width > maxWidth && current) {
          lines.push(current);
          current = word;
        } else {
          current = test;
        }
      }
      if (current) lines.push(current);

      const lineHeight = fontSize * 1.42;
      const totalHeight = lines.length * lineHeight;
      let startY = (dimensions.h - totalHeight) / 2 + fontSize * 0.5;

      for (const line of lines) {
        ctx.fillText(line, padding, startY);
        startY += lineHeight;
      }

      ctx.fillStyle = active.fg;
      ctx.globalAlpha = 0.85;
      ctx.font = `600 ${Math.round(dimensions.w * 0.028)}px "Plus Jakarta Sans", sans-serif`;
      ctx.fillText(`— ${quote.author}`, padding, startY + 26);

      ctx.globalAlpha = 0.6;
      ctx.font = `500 ${Math.round(dimensions.w * 0.02)}px "JetBrains Mono", monospace`;
      ctx.fillText('QuoteVerse', padding, dimensions.h - padding * 0.6);
      ctx.globalAlpha = 1;
    };

    ctx.fillStyle = active.bg;
    ctx.fillRect(0, 0, dimensions.w, dimensions.h);

    if (active.image) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        if (cancelled) return;
        const scale = Math.max(dimensions.w / img.width, dimensions.h / img.height);
        const dw = img.width * scale;
        const dh = img.height * scale;
        ctx.drawImage(img, (dimensions.w - dw) / 2, (dimensions.h - dh) / 2, dw, dh);
        drawTextAndOverlay();
      };
      img.onerror = drawTextAndOverlay;
      img.src = active.image;
    } else {
      drawTextAndOverlay();
    }

    return () => {
      cancelled = true;
    };
  }, [preset, fontFamily, aspect, quote, dimensions.w, dimensions.h]);

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `quoteverse-${quote.author.toLowerCase().replace(/\s+/g, '-')}.png`;
    a.click();
    onDownloaded();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="studio-modal-title"
    >
      <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700 rounded-xl max-w-4xl w-full p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 max-h-[90vh] overflow-y-auto">
        <div className="lg:col-span-7 flex flex-col items-center justify-center bg-slate-100 dark:bg-slate-900 rounded-xl p-4">
          <canvas
            ref={canvasRef}
            width={dimensions.w}
            height={dimensions.h}
            data-testid="quote-studio-canvas"
            className="max-w-full max-h-[420px] rounded-lg border border-slate-200 dark:border-slate-700 object-contain"
          />
        </div>

        <div className="lg:col-span-5 flex flex-col justify-between gap-6">
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <h3 id="studio-modal-title" className="text-base font-semibold text-slate-900 dark:text-white">
                Quote Image Studio
              </h3>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close Quote Image Studio"
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-medium text-slate-600 dark:text-slate-300">Background Style</p>
              <div className="grid grid-cols-2 gap-2">
                {BACKDROPS.map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => setPreset(b.id)}
                    className={`px-3 py-2 rounded-lg text-xs font-medium border text-left transition-colors ${
                      preset === b.id
                        ? 'border-[#4338CA] bg-[#4338CA]/10 text-[#4338CA] dark:text-indigo-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {b.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-medium text-slate-600 dark:text-slate-300">Typography</p>
              <div className="grid grid-cols-3 gap-2">
                {(['Fraunces', 'Plus Jakarta Sans', 'JetBrains Mono'] as StudioFont[]).map((f) => (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setFontFamily(f)}
                    className={`px-2.5 py-2 rounded-lg text-xs font-medium border truncate ${
                      fontFamily === f
                        ? 'border-[#4338CA] bg-[#4338CA]/10 text-[#4338CA] dark:text-indigo-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {f.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-medium text-slate-600 dark:text-slate-300">Poster Aspect</p>
              <div className="grid grid-cols-3 gap-2">
                {([
                  { id: '1:1', label: '1:1 Square' },
                  { id: '4:5', label: '4:5 Story' },
                  { id: '16:9', label: '16:9 Wide' },
                ] as { id: AspectPreset; label: string }[]).map((a) => (
                  <button
                    key={a.id}
                    type="button"
                    onClick={() => setAspect(a.id)}
                    className={`px-2.5 py-2 rounded-lg text-xs font-medium border ${
                      aspect === a.id
                        ? 'border-[#4338CA] bg-[#4338CA]/10 text-[#4338CA] dark:text-indigo-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {a.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleDownload}
            className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#4338CA] hover:bg-[#3730A3] text-white text-sm font-medium"
          >
            <Download className="w-4 h-4" />
            Download PNG Poster
          </button>
        </div>
      </div>
    </div>
  );
};
