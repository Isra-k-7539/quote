import React, { useState } from 'react';
import { Bell, CheckCircle2, Moon, Sun } from 'lucide-react';
import { ALL_CATEGORIES } from '../data/quotesCatalog.ts';
import type { ApiProviderOption } from '../types/quoteverse.ts';

interface SettingsViewProps {
  theme: 'light' | 'dark';
  dailyInspirationEnabled: boolean;
  preferredCategory: string;
  preferredApiProvider: ApiProviderOption;
  onUpdateSettings: (updates: {
    theme?: 'light' | 'dark';
    dailyInspirationEnabled?: boolean;
    preferredCategory?: string;
    preferredApiProvider?: ApiProviderOption;
  }) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  theme,
  dailyInspirationEnabled,
  preferredCategory,
  preferredApiProvider,
  onUpdateSettings,
}) => {
  const [savedNotice, setSavedNotice] = useState(false);

  const handleToggleDaily = async () => {
    const next = !dailyInspirationEnabled;
    if (next && typeof Notification !== 'undefined' && Notification.permission === 'default') {
      try {
        await Notification.requestPermission();
      } catch {
        // Browser notification prompt unsupported in sandbox
      }
    }
    onUpdateSettings({ dailyInspirationEnabled: next });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2000);
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
            Workspace &amp; Reader Preferences
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Settings sync automatically to Firestore when signed in, or locally in Guest Mode.
          </p>
        </div>
        {savedNotice && (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
            Preferences updated
          </span>
        )}
      </div>

      {/* Appearance */}
      <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Appearance</h3>
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-slate-800 dark:text-slate-200">Color Theme</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Switch between crisp Off-White Light Mode and Deep Slate Dark Mode.
            </p>
          </div>
          <div className="inline-flex p-1 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={() => onUpdateSettings({ theme: 'light' })}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                theme === 'light'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Sun className="w-3.5 h-3.5" />
              Light
            </button>
            <button
              type="button"
              onClick={() => onUpdateSettings({ theme: 'dark' })}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                theme === 'dark'
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Moon className="w-3.5 h-3.5" />
              Dark
            </button>
          </div>
        </div>
      </section>

      {/* Quote Generation Defaults */}
      <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
          Generator Defaults
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label htmlFor="pref-cat" className="block text-xs font-medium text-slate-600 dark:text-slate-300">
              Default Category
            </label>
            <select
              id="pref-cat"
              value={preferredCategory}
              onChange={(e) => {
                onUpdateSettings({ preferredCategory: e.target.value });
                setSavedNotice(true);
                setTimeout(() => setSavedNotice(false), 1800);
              }}
              className="w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
            >
              <option value="All">All Categories</option>
              {ALL_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label htmlFor="pref-api" className="block text-xs font-medium text-slate-600 dark:text-slate-300">
              Default External Quote Provider
            </label>
            <select
              id="pref-api"
              value={preferredApiProvider}
              onChange={(e) => {
                onUpdateSettings({ preferredApiProvider: e.target.value as ApiProviderOption });
                setSavedNotice(true);
                setTimeout(() => setSavedNotice(false), 1800);
              }}
              className="w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
            >
              <option value="auto">Auto (Multi-Provider + Fallback)</option>
              <option value="dummyjson">DummyJSON Quotes API</option>
              <option value="zenquotes">ZenQuotes API</option>
              <option value="quotable">Quotable API</option>
              <option value="curated">QuoteVerse Archive</option>
            </select>
          </div>
        </div>
      </section>

      {/* Daily Inspiration Notifications */}
      <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <Bell className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-slate-900 dark:text-white">
                Daily Inspiration Digest
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Receive a morning reminder featuring QuoteVerse&apos;s Quote of the Day.
              </p>
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={dailyInspirationEnabled}
            onClick={handleToggleDaily}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors ${
              dailyInspirationEnabled ? 'bg-[#4338CA]' : 'bg-slate-300 dark:bg-slate-600'
            }`}
          >
            <span
              className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${
                dailyInspirationEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </section>
    </div>
  );
};
