import React from 'react';
import {
  BarChart3,
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Compass,
  Heart,
  History,
  LayoutDashboard,
  Settings,
  Sparkles,
  UserCircle,
  X,
} from 'lucide-react';
import type { NavSection } from '../types/quoteverse.ts';

interface SidebarProps {
  activeSection: NavSection;
  onSelect: (section: NavSection) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  userDisplayName: string;
  userEmail: string;
  userPhotoUrl: string;
  isAuthenticated: boolean;
  historyCount: number;
  favoritesCount: number;
}

const NAV_ITEMS: { id: NavSection; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'generator', label: 'Generate Quote', icon: Sparkles },
  { id: 'history', label: 'Quote History', icon: History },
  { id: 'favorites', label: 'Favorites', icon: Heart },
  { id: 'categories', label: 'Explore Categories', icon: Compass },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'settings', label: 'Settings', icon: Settings },
  { id: 'profile', label: 'User Profile', icon: UserCircle },
];

export const Sidebar: React.FC<SidebarProps> = ({
  activeSection,
  onSelect,
  collapsed,
  onToggleCollapse,
  mobileOpen,
  onCloseMobile,
  userDisplayName,
  userEmail,
  userPhotoUrl,
  isAuthenticated,
  historyCount,
  favoritesCount,
}) => {
  const defaultAvatar = '/src/assets/images/quoteverse_default_avatar_1795431221240.jpg';

  const navContent = (isMobileDrawer: boolean) => {
    const isCompact = !isMobileDrawer && collapsed;
    return (
      <div className="flex flex-col h-full bg-white dark:bg-[#0F172A] border-r border-slate-200 dark:border-slate-800">
        {/* Brand Row */}
        <div
          className={`flex items-center h-16 px-4 border-b border-slate-200 dark:border-slate-800 ${
            isCompact ? 'justify-center' : 'justify-between'
          }`}
        >
          <button
            type="button"
            onClick={() => {
              onSelect('dashboard');
              if (isMobileDrawer) onCloseMobile();
            }}
            className="flex items-center gap-2.5 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4338CA] rounded-md"
            aria-label="QuoteVerse Home"
          >
            <span className="w-8 h-8 rounded-lg bg-[#4338CA] text-white flex items-center justify-center shrink-0">
              <BookOpen className="w-4 h-4" />
            </span>
            {!isCompact && (
              <span className="font-serif text-lg font-semibold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0">
                QuoteVerse
              </span>
            )}
          </button>

          {isMobileDrawer ? (
            <button
              type="button"
              onClick={onCloseMobile}
              aria-label="Close navigation menu"
              className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          ) : (
            <button
              type="button"
              onClick={onToggleCollapse}
              aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              className={`p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${
                isCompact ? 'hidden' : ''
              }`}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Navigation Links */}
        <nav aria-label="Primary Navigation" className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            const countText =
              item.id === 'history'
                ? historyCount
                : item.id === 'favorites'
                  ? favoritesCount
                  : null;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onSelect(item.id);
                  if (isMobileDrawer) onCloseMobile();
                }}
                aria-current={isActive ? 'page' : undefined}
                title={isCompact ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                  isCompact ? 'justify-center px-2' : 'justify-between'
                } ${
                  isActive
                    ? 'bg-[#4338CA]/10 text-[#4338CA] dark:bg-[#4338CA]/25 dark:text-indigo-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span className="flex items-center gap-3 min-w-0">
                  <Icon className="w-4 h-4 shrink-0" />
                  {!isCompact && <span className="truncate">{item.label}</span>}
                </span>
                {!isCompact && countText !== null && (
                  <span className="text-xs font-mono tabular-nums text-slate-400 dark:text-slate-500">
                    {countText}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {isCompact && (
          <div className="px-3 py-2 border-t border-slate-200 dark:border-slate-800 flex justify-center">
            <button
              type="button"
              onClick={onToggleCollapse}
              aria-label="Expand sidebar"
              className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Account Footer */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={() => {
              onSelect('profile');
              if (isMobileDrawer) onCloseMobile();
            }}
            className={`w-full flex items-center gap-3 p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/70 transition-colors text-left ${
              isCompact ? 'justify-center' : ''
            }`}
            aria-label="Open User Profile"
          >
            <img
              src={userPhotoUrl || defaultAvatar}
              alt={userDisplayName}
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = defaultAvatar;
              }}
              className="w-8 h-8 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
            />
            {!isCompact && (
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                  {userDisplayName}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  {isAuthenticated ? userEmail : 'Guest mode · Local archive'}
                </p>
              </div>
            )}
          </button>
        </div>
      </div>
    );
  };

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:block shrink-0 transition-all duration-200 ${
          collapsed ? 'w-[72px]' : 'w-64'
        }`}
      >
        <div className="sticky top-0 h-screen">{navContent(false)}</div>
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/50 backdrop-blur-xs"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative w-72 max-w-[85vw] h-full z-10">{navContent(true)}</div>
        </div>
      )}
    </>
  );
};
