import React, { useMemo, useState } from 'react';
import { FolderPlus, Heart, Search, Trash2 } from 'lucide-react';
import { ALL_CATEGORIES } from '../data/quotesCatalog.ts';
import type { FavoriteEntry, QuoteCollection } from '../types/quoteverse.ts';
import { QuoteCard } from './QuoteCard.tsx';

interface FavoritesViewProps {
  favorites: FavoriteEntry[];
  collections: QuoteCollection[];
  onRemoveFavorite: (quoteId: string) => void;
  onAssignCollection: (favoriteId: string, collectionId: string) => void;
  onCreateCollection: (name: string, description: string, color: string) => void;
  onDeleteCollection: (collectionId: string) => void;
  onOpenStudio: (fav: FavoriteEntry) => void;
  onOpenWorkspace: (fav: FavoriteEntry) => void;
  onGoToGenerator: () => void;
}

const COLLECTION_COLORS = ['#4338CA', '#8B5CF6', '#F59E0B', '#0D9488', '#DC2626'];

export const FavoritesView: React.FC<FavoritesViewProps> = ({
  favorites,
  collections,
  onRemoveFavorite,
  onAssignCollection,
  onCreateCollection,
  onDeleteCollection,
  onOpenStudio,
  onOpenWorkspace,
  onGoToGenerator,
}) => {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [selectedCollectionId, setSelectedCollectionId] = useState<string>('all');
  const [showNewColForm, setShowNewColForm] = useState(false);
  const [newColName, setNewColName] = useState('');
  const [newColDesc, setNewColDesc] = useState('');
  const [newColColor, setNewColColor] = useState(COLLECTION_COLORS[0]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return favorites.filter((f) => {
      if (categoryFilter !== 'All' && f.category !== categoryFilter) return false;
      if (selectedCollectionId === 'unassigned' && f.collectionId !== '') return false;
      if (
        selectedCollectionId !== 'all' &&
        selectedCollectionId !== 'unassigned' &&
        f.collectionId !== selectedCollectionId
      ) {
        return false;
      }
      if (q) {
        return (
          f.quoteText.toLowerCase().includes(q) ||
          f.author.toLowerCase().includes(q) ||
          f.category.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [favorites, search, categoryFilter, selectedCollectionId]);

  const handleCreateCol = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newColName.trim()) return;
    onCreateCollection(newColName.trim(), newColDesc.trim(), newColColor);
    setNewColName('');
    setNewColDesc('');
    setShowNewColForm(false);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <aside className="lg:col-span-4 space-y-4">
        <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                Personal Collections
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Organize favorite quotes into folders
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowNewColForm((v) => !v)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#4338CA] hover:bg-[#3730A3] text-white text-xs font-medium whitespace-nowrap shrink-0"
            >
              <FolderPlus className="w-3.5 h-3.5" />
              New Folder
            </button>
          </div>

          {showNewColForm && (
            <form onSubmit={handleCreateCol} className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-700/60">
              <div>
                <label htmlFor="col-name" className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Collection Name
                </label>
                <input
                  id="col-name"
                  type="text"
                  required
                  value={newColName}
                  onChange={(e) => setNewColName(e.target.value)}
                  placeholder="e.g., Morning Clarity"
                  className="w-full px-3 py-1.5 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                />
              </div>
              <div>
                <label htmlFor="col-desc" className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                  Description
                </label>
                <input
                  id="col-desc"
                  type="text"
                  value={newColDesc}
                  onChange={(e) => setNewColDesc(e.target.value)}
                  placeholder="Optional note..."
                  className="w-full px-3 py-1.5 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {COLLECTION_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setNewColColor(c)}
                      aria-label={`Select color ${c}`}
                      className={`w-5 h-5 rounded-full transition-transform ${
                        newColColor === c ? 'ring-2 ring-offset-2 ring-slate-900 dark:ring-white scale-110' : ''
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-lg bg-[#4338CA] text-white text-xs font-medium"
                >
                  Create
                </button>
              </div>
            </form>
          )}

          <div className="space-y-1">
            <button
              type="button"
              onClick={() => setSelectedCollectionId('all')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors ${
                selectedCollectionId === 'all'
                  ? 'bg-[#4338CA]/10 text-[#4338CA] dark:bg-[#4338CA]/25 dark:text-indigo-300 font-medium'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <span>All Favorites</span>
              <span className="font-mono text-xs tabular-nums">{favorites.length}</span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedCollectionId('unassigned')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors ${
                selectedCollectionId === 'unassigned'
                  ? 'bg-[#4338CA]/10 text-[#4338CA] dark:bg-[#4338CA]/25 dark:text-indigo-300 font-medium'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <span>Unfiled</span>
              <span className="font-mono text-xs tabular-nums">
                {favorites.filter((f) => !f.collectionId).length}
              </span>
            </button>

            {collections.map((col) => {
              const count = favorites.filter((f) => f.collectionId === col.id).length;
              return (
                <div
                  key={col.id}
                  className={`flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors ${
                    selectedCollectionId === col.id
                      ? 'bg-[#4338CA]/10 text-[#4338CA] dark:bg-[#4338CA]/25 dark:text-indigo-300 font-medium'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setSelectedCollectionId(col.id)}
                    className="flex items-center gap-2.5 min-w-0 flex-1 text-left"
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-sm shrink-0"
                      style={{ backgroundColor: col.color }}
                    />
                    <span className="truncate">{col.name}</span>
                  </button>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="font-mono text-xs tabular-nums">{count}</span>
                    <button
                      type="button"
                      onClick={() => {
                        if (selectedCollectionId === col.id) setSelectedCollectionId('all');
                        onDeleteCollection(col.id);
                      }}
                      aria-label={`Delete collection ${col.name}`}
                      className="p-1 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </aside>

      <div className="lg:col-span-8 space-y-4">
        <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-4 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search favorites..."
              aria-label="Search favorites"
              className="w-full pl-9 pr-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
            />
          </div>
          <select
            aria-label="Filter favorites by category"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
          >
            <option value="All">All Categories</option>
            {ALL_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        {filtered.length === 0 ? (
          <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-10 text-center space-y-3">
            <Heart className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto" />
            <p className="text-base font-medium text-slate-900 dark:text-white">
              No favorite quotes in this view
            </p>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Mark quotes as favorites while generating or browsing to build your curated library.
            </p>
            <button
              type="button"
              onClick={onGoToGenerator}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#4338CA] text-white text-sm font-medium hover:bg-[#3730A3]"
            >
              Discover Quotes
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {filtered.map((fav) => (
              <div key={fav.id} className="space-y-2">
                <QuoteCard
                  quote={{
                    id: fav.id,
                    quoteId: fav.quoteId,
                    quoteText: fav.quoteText,
                    author: fav.author,
                    category: fav.category,
                    source: fav.source,
                    timestamp: fav.createdAt,
                    isFavorite: true,
                  }}
                  onToggleFavorite={() => onRemoveFavorite(fav.quoteId)}
                  onOpenStudio={() => onOpenStudio(fav)}
                  onOpenWorkspace={() => onOpenWorkspace(fav)}
                  compact
                />
                {collections.length > 0 && (
                  <div className="flex items-center justify-end gap-2 px-2">
                    <label
                      htmlFor={`assign-col-${fav.id}`}
                      className="text-xs text-slate-500 dark:text-slate-400"
                    >
                      Folder:
                    </label>
                    <select
                      id={`assign-col-${fav.id}`}
                      value={fav.collectionId}
                      onChange={(e) => onAssignCollection(fav.id, e.target.value)}
                      className="px-2.5 py-1 text-xs rounded-md bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200"
                    >
                      <option value="">Unfiled</option>
                      {collections.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
