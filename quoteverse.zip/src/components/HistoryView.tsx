import React, { useMemo, useState } from 'react';
import {
  ArrowDownUp,
  Download,
  FileJson,
  Search,
  Sparkles,
  X,
} from 'lucide-react';
import { ALL_CATEGORIES } from '../data/quotesCatalog.ts';
import type { HistoryEntry } from '../types/quoteverse.ts';
import { buildCsvExport, buildJsonExport, filterHistoryEntries } from '../utils/quoteLogic.ts';
import { QuoteCard } from './QuoteCard.tsx';

interface HistoryViewProps {
  entries: HistoryEntry[];
  searchQuery: string;
  onSearchChange: (val: string) => void;
  isFavorite: (quoteId: string) => boolean;
  onToggleFavorite: (entry: HistoryEntry) => void;
  onDeleteHistory: (historyId: string) => void;
  onOpenStudio: (entry: HistoryEntry) => void;
  onOpenWorkspace: (entry: HistoryEntry) => void;
  onGroundQuote: (entry: HistoryEntry) => void;
  onGoToGenerator: () => void;
  onLogExport: (format: 'CSV' | 'JSON') => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  entries,
  searchQuery,
  onSearchChange,
  isFavorite,
  onToggleFavorite,
  onDeleteHistory,
  onOpenStudio,
  onOpenWorkspace,
  onGroundQuote,
  onGoToGenerator,
  onLogExport,
}) => {
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [authorFilter, setAuthorFilter] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [pageSize, setPageSize] = useState(8);
  const [detailItem, setDetailItem] = useState<HistoryEntry | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<HistoryEntry | null>(null);

  const uniqueAuthors = useMemo(() => {
    return Array.from(new Set(entries.map((e) => e.author))).sort();
  }, [entries]);

  const filtered = useMemo(() => {
    return filterHistoryEntries(entries, {
      search: searchQuery,
      category: categoryFilter,
      author: authorFilter,
      dateFrom,
      dateTo,
      sort: sortOrder,
    });
  }, [entries, searchQuery, categoryFilter, authorFilter, dateFrom, dateTo, sortOrder]);

  const visible = filtered.slice(0, pageSize);
  const hasMore = visible.length < filtered.length;

  const triggerDownload = (content: string, filename: string, mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportCsv = () => {
    triggerDownload(buildCsvExport(filtered), 'quoteverse-history.csv', 'text/csv;charset=utf-8;');
    onLogExport('CSV');
  };

  const handleExportJson = () => {
    triggerDownload(buildJsonExport(filtered), 'quoteverse-history.json', 'application/json');
    onLogExport('JSON');
  };

  return (
    <div className="space-y-6">
      <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
              Quote History Archive
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
              Showing {visible.length} of {filtered.length} matching records ({entries.length} total)
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleExportCsv}
              disabled={filtered.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>
            <button
              type="button"
              onClick={handleExportJson}
              disabled={filtered.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              <FileJson className="w-3.5 h-3.5" />
              Export JSON
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search quote text or author..."
              aria-label="Search quote history"
              className="w-full pl-9 pr-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4338CA]"
            />
          </div>

          <select
            aria-label="Filter history by category"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4338CA]"
          >
            <option value="All">All Categories</option>
            {ALL_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <select
            aria-label="Filter history by author"
            value={authorFilter}
            onChange={(e) => setAuthorFilter(e.target.value)}
            className="px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4338CA]"
          >
            <option value="">All Authors</option>
            {uniqueAuthors.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>

          <input
            type="date"
            aria-label="Filter history from date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className="px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4338CA]"
          />

          <div className="flex items-center gap-2">
            <input
              type="date"
              aria-label="Filter history to date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
              className="w-full min-w-0 px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#4338CA]"
            />
            <button
              type="button"
              onClick={() => setSortOrder((s) => (s === 'newest' ? 'oldest' : 'newest'))}
              title={`Sort: ${sortOrder === 'newest' ? 'Newest first' : 'Oldest first'}`}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
            >
              <ArrowDownUp className="w-3.5 h-3.5" />
              <span>{sortOrder === 'newest' ? 'Newest' : 'Oldest'}</span>
            </button>
          </div>
        </div>
      </section>

      {visible.length === 0 ? (
        <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-10 text-center space-y-3">
          <p className="text-base font-medium text-slate-900 dark:text-white">
            No matching quotes in history
          </p>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Adjust your filters or generate a new quote to add it to your archive.
          </p>
          <div className="flex items-center justify-center gap-2 pt-2">
            {(searchQuery || categoryFilter !== 'All' || authorFilter || dateFrom || dateTo) && (
              <button
                type="button"
                onClick={() => {
                  onSearchChange('');
                  setCategoryFilter('All');
                  setAuthorFilter('');
                  setDateFrom('');
                  setDateTo('');
                }}
                className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-700 dark:text-slate-200"
              >
                Clear Filters
              </button>
            )}
            <button
              type="button"
              onClick={onGoToGenerator}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#4338CA] text-white text-sm font-medium hover:bg-[#3730A3]"
            >
              <Sparkles className="w-4 h-4" />
              Generate Quote
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {visible.map((entry) => (
            <QuoteCard
              key={entry.id}
              quote={{
                id: entry.id,
                quoteId: entry.quoteId,
                quoteText: entry.quoteText,
                author: entry.author,
                category: entry.category,
                source: entry.source,
                timestamp: entry.generatedAt,
                mood: entry.mood,
                isFavorite: isFavorite(entry.quoteId),
              }}
              onToggleFavorite={() => onToggleFavorite(entry)}
              onOpenStudio={() => onOpenStudio(entry)}
              onOpenWorkspace={() => onOpenWorkspace(entry)}
              onGroundWithAi={() => onGroundQuote(entry)}
              onViewDetails={() => setDetailItem(entry)}
              onDelete={() => setDeleteTarget(entry)}
              compact
            />
          ))}

          {hasMore && (
            <div className="flex justify-center pt-2">
              <button
                type="button"
                onClick={() => setPageSize((p) => p + 8)}
                className="px-5 py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                Load More ({filtered.length - visible.length} remaining)
              </button>
            </div>
          )}
        </div>
      )}

      {detailItem && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="detail-modal-title"
        >
          <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700 rounded-xl max-w-lg w-full p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 id="detail-modal-title" className="text-base font-semibold text-slate-900 dark:text-white">
                Quote Record Details
              </h3>
              <button
                type="button"
                onClick={() => setDetailItem(null)}
                aria-label="Close detail modal"
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <blockquote className="font-serif text-xl text-slate-900 dark:text-white leading-relaxed">
              “{detailItem.quoteText}”
            </blockquote>
            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
              — {detailItem.author}
            </p>

            <dl className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-100 dark:border-slate-700/60 text-xs">
              <div>
                <dt className="text-slate-500 dark:text-slate-400">Category</dt>
                <dd className="font-medium text-slate-900 dark:text-slate-100">{detailItem.category}</dd>
              </div>
              <div>
                <dt className="text-slate-500 dark:text-slate-400">Source Provider</dt>
                <dd className="font-medium text-slate-900 dark:text-slate-100">{detailItem.source}</dd>
              </div>
              <div>
                <dt className="text-slate-500 dark:text-slate-400">Mood Context</dt>
                <dd className="font-medium text-slate-900 dark:text-slate-100">{detailItem.mood || 'General'}</dd>
              </div>
              <div>
                <dt className="text-slate-500 dark:text-slate-400">Canonical Quote ID</dt>
                <dd className="font-mono text-slate-700 dark:text-slate-300 truncate">{detailItem.quoteId}</dd>
              </div>
            </dl>
          </div>
        </div>
      )}

      {deleteTarget && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-modal-title"
        >
          <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700 rounded-xl max-w-md w-full p-6 space-y-4">
            <h3 id="delete-modal-title" className="text-base font-semibold text-slate-900 dark:text-white">
              Delete quote from history?
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              This will permanently remove “{deleteTarget.quoteText.slice(0, 80)}...” by{' '}
              {deleteTarget.author} from your history timeline.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteHistory(deleteTarget.id);
                  setDeleteTarget(null);
                }}
                className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-sm font-medium"
              >
                Delete Quote
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
