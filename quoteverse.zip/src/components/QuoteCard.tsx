import React, { useState } from 'react';
import {
  Check,
  Copy,
  Globe,
  Heart,
  Image as ImageIcon,
  Layers,
  Share2,
  Trash2,
} from 'lucide-react';

export interface QuoteCardItem {
  id: string;
  quoteId: string;
  quoteText: string;
  author: string;
  category: string;
  source: string;
  timestamp: string;
  mood?: string;
  isFavorite: boolean;
}

interface QuoteCardProps {
  quote: QuoteCardItem;
  onToggleFavorite: () => void;
  onOpenStudio: () => void;
  onOpenWorkspace: () => void;
  onGroundWithAi?: () => void;
  onDelete?: () => void;
  onViewDetails?: () => void;
  compact?: boolean;
}

export const QuoteCard: React.FC<QuoteCardProps> = ({
  quote,
  onToggleFavorite,
  onOpenStudio,
  onOpenWorkspace,
  onGroundWithAi,
  onDelete,
  onViewDetails,
  compact = false,
}) => {
  const [copied, setCopied] = useState(false);

  const formattedDate = (() => {
    try {
      return new Intl.DateTimeFormat('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
      }).format(new Date(quote.timestamp));
    } catch {
      return quote.timestamp;
    }
  })();

  const handleCopy = async () => {
    const text = `"${quote.quoteText}" — ${quote.author}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback ignored in restricted headless contexts
    }
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(`"${quote.quoteText}" — ${quote.author} (via QuoteVerse)`);
    window.open(`https://wa.me/?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <article className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-5 sm:p-6 transition-colors hover:border-slate-300 dark:hover:border-slate-600 flex flex-col justify-between gap-4">
      <div className="space-y-3">
        {/* Clean Zero-Pill Metadata */}
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
          <span className="font-medium text-[#4338CA] dark:text-indigo-300">{quote.category}</span>
          <span aria-hidden="true">·</span>
          <span>{quote.source}</span>
          {quote.mood && (
            <>
              <span aria-hidden="true">·</span>
              <span>Mood: {quote.mood}</span>
            </>
          )}
          <span aria-hidden="true">·</span>
          <time className="font-mono tabular-nums" dateTime={quote.timestamp}>
            {formattedDate}
          </time>
        </div>

        {/* Quote Text */}
        <blockquote
          className={`font-serif text-slate-900 dark:text-slate-50 leading-relaxed ${
            compact ? 'text-lg' : 'text-xl sm:text-[22px]'
          }`}
        >
          “{quote.quoteText}”
        </blockquote>

        <p className="text-sm font-medium text-slate-700 dark:text-slate-300">— {quote.author}</p>
      </div>

      {/* Action Bar */}
      <div className="pt-3 border-t border-slate-100 dark:border-slate-700/60 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={onToggleFavorite}
            aria-label={quote.isFavorite ? `Remove "${quote.author}" quote from favorites` : `Save "${quote.author}" quote to favorites`}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              quote.isFavorite
                ? 'bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-500/30'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-transparent'
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${quote.isFavorite ? 'fill-current' : ''}`} />
            <span>{quote.isFavorite ? 'Favorited' : 'Favorite'}</span>
          </button>

          <button
            type="button"
            onClick={handleCopy}
            aria-label={`Copy quote by ${quote.author}`}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>

          <button
            type="button"
            onClick={onOpenStudio}
            aria-label={`Create quote image for ${quote.author}`}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Image Studio</span>
          </button>

          <button
            type="button"
            onClick={handleShareWhatsApp}
            aria-label={`Share quote by ${quote.author} on WhatsApp`}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Share</span>
          </button>

          {onGroundWithAi && (
            <button
              type="button"
              onClick={onGroundWithAi}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-[#4338CA] dark:text-indigo-300 hover:bg-[#4338CA]/10 transition-colors whitespace-nowrap shrink-0"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>AI Context</span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenWorkspace}
            aria-label={`Send quote by ${quote.author} to Workspace or Notes`}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Workspace</span>
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          {onViewDetails && (
            <button
              type="button"
              onClick={onViewDetails}
              className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
            >
              Details
            </button>
          )}
          {onDelete && (
            <button
              type="button"
              onClick={onDelete}
              aria-label={`Delete quote by ${quote.author} from history`}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-500/10 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </article>
  );
};
