import React, { useEffect, useState } from 'react';
import { CheckCircle2, CheckSquare, MessageSquare, NotebookPen, X } from 'lucide-react';
import {
  createGoogleTaskApi,
  fetchGoogleChatSpacesApi,
  fetchGoogleTaskListsApi,
  sendGoogleChatMessageApi,
  type GoogleChatSpace,
  type GoogleTaskList,
} from '../services/apiClient.ts';
import { getProjectId, getWorkspaceAccessToken } from '../lib/firebase.ts';

interface WorkspaceActionModalProps {
  quote: {
    quoteId: string;
    quoteText: string;
    author: string;
    category: string;
  };
  isAuthenticated: boolean;
  onSignIn: () => Promise<void>;
  onSaveNote: (note: {
    quoteId: string;
    title: string;
    body: string;
    quoteText: string;
    author: string;
  }) => Promise<void>;
  onLogWorkspaceAction: (type: 'task_sync' | 'chat_share', details: string) => void;
  onClose: () => void;
}

type TabMode = 'note' | 'tasks' | 'chat';

export const WorkspaceActionModal: React.FC<WorkspaceActionModalProps> = ({
  quote,
  isAuthenticated,
  onSignIn,
  onSaveNote,
  onLogWorkspaceAction,
  onClose,
}) => {
  const [tab, setTab] = useState<TabMode>('note');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Reflection Note state (Keep-compatible)
  const [noteTitle, setNoteTitle] = useState(`Reflection on ${quote.author}`);
  const [noteBody, setNoteBody] = useState(`"${quote.quoteText}"\n\nMy takeaway: `);

  // Google Tasks state
  const [taskLists, setTaskLists] = useState<GoogleTaskList[]>([]);
  const [selectedListId, setSelectedListId] = useState('@default');
  const [taskTitle, setTaskTitle] = useState(`Reflect on: ${quote.author}`);
  const [taskDue, setTaskDue] = useState('');

  // Google Chat state
  const [chatSpaces, setChatSpaces] = useState<GoogleChatSpace[]>([]);
  const [selectedSpace, setSelectedSpace] = useState('');
  const [chatMessage, setChatMessage] = useState(`"${quote.quoteText}" — ${quote.author}`);
  const [confirmChatSend, setConfirmChatSend] = useState(false);

  const token = getWorkspaceAccessToken();
  const projectId = getProjectId();

  useEffect(() => {
    setStatusMsg(null);
    setErrorMsg(null);
    setConfirmChatSend(false);
    if (!token) return;

    if (tab === 'tasks' && taskLists.length === 0) {
      fetchGoogleTaskListsApi(token)
        .then((items) => {
          setTaskLists(items);
          if (items[0]?.id) setSelectedListId(items[0].id);
        })
        .catch((err) => {
          setErrorMsg(
            err?.response?.data?.error || 'Could not load Google Task lists.'
          );
        });
    } else if (tab === 'chat' && chatSpaces.length === 0) {
      fetchGoogleChatSpacesApi(token)
        .then((spaces) => {
          setChatSpaces(spaces);
          if (spaces[0]?.name) setSelectedSpace(spaces[0].name);
        })
        .catch((err) => {
          setErrorMsg(
            err?.response?.data?.error ||
              'Google Chat requires a Business/Enterprise Google Workspace account and a configured Chat app.'
          );
        });
    }
  }, [tab, token, taskLists.length, chatSpaces.length]);

  const handleSaveNoteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim() || !noteBody.trim()) return;
    setBusy(true);
    setErrorMsg(null);
    try {
      await onSaveNote({
        quoteId: quote.quoteId,
        title: noteTitle.trim(),
        body: noteBody.trim(),
        quoteText: quote.quoteText,
        author: quote.author,
      });
      setStatusMsg('Reflection note saved to your QuoteVerse archive.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to save reflection note.');
    } finally {
      setBusy(false);
    }
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) {
      setErrorMsg('Sign in with Google to authorize Google Tasks access.');
      return;
    }
    setBusy(true);
    setErrorMsg(null);
    try {
      await createGoogleTaskApi(token, {
        listId: selectedListId,
        title: taskTitle.trim(),
        notes: `"${quote.quoteText}" — ${quote.author} (${quote.category})`,
        due: taskDue || undefined,
      });
      onLogWorkspaceAction('task_sync', `Created Google Task: ${taskTitle}`);
      setStatusMsg('Task created in Google Tasks!');
    } catch (err: unknown) {
      setErrorMsg(
        (err as { response?: { data?: { error?: string } } })?.response?.data?.error ||
          'Failed to create Google Task.'
      );
    } finally {
      setBusy(false);
    }
  };

  const handleSendChat = async () => {
    if (!token || !selectedSpace || !chatMessage.trim()) return;
    setBusy(true);
    setErrorMsg(null);
    try {
      await sendGoogleChatMessageApi(token, {
        spaceName: selectedSpace,
        text: chatMessage.trim(),
      });
      onLogWorkspaceAction('chat_share', `Shared quote to Google Chat space`);
      setStatusMsg('Quote posted to Google Chat!');
      setConfirmChatSend(false);
    } catch (err: unknown) {
      setErrorMsg(
        (err as { response?: { data?: { error?: string } } })?.response?.data?.error ||
          'Failed to send message to Google Chat.'
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/55 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="workspace-modal-title"
    >
      <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700 rounded-xl max-w-lg w-full p-6 space-y-5 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between">
          <h3 id="workspace-modal-title" className="text-base font-semibold text-slate-900 dark:text-white">
            Save &amp; Share to Workspace
          </h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Workspace modal"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700/70">
          <p className="font-serif text-sm text-slate-900 dark:text-slate-100">
            “{quote.quoteText}”
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">— {quote.author}</p>
        </div>

        {/* Mode Tabs */}
        <div className="grid grid-cols-3 gap-1 p-1 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
          <button
            type="button"
            onClick={() => setTab('note')}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
              tab === 'note'
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <NotebookPen className="w-3.5 h-3.5" />
            <span>Note (Keep)</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('tasks')}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
              tab === 'tasks'
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <CheckSquare className="w-3.5 h-3.5" />
            <span>Google Tasks</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('chat')}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
              tab === 'chat'
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Google Chat</span>
          </button>
        </div>

        {statusMsg && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30 text-xs text-emerald-700 dark:text-emerald-200">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{statusMsg}</span>
          </div>
        )}

        {errorMsg && (
          <div role="alert" className="p-3 rounded-lg bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/30 text-xs text-rose-700 dark:text-rose-200 space-y-1">
            <p>{errorMsg}</p>
            {tab === 'chat' && (
              <a
                href={`https://console.cloud.google.com/apis/api/chat.googleapis.com/hangouts-chat?project=${projectId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="underline font-medium inline-block"
              >
                Configure Google Chat App in Cloud Console
              </a>
            )}
          </div>
        )}

        {tab === 'note' && (
          <form onSubmit={handleSaveNoteSubmit} className="space-y-3">
            <div>
              <label htmlFor="note-title" className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Note Title
              </label>
              <input
                id="note-title"
                type="text"
                required
                value={noteTitle}
                onChange={(e) => setNoteTitle(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label htmlFor="note-body" className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Reflection Note
              </label>
              <textarea
                id="note-body"
                rows={4}
                required
                value={noteBody}
                onChange={(e) => setNoteBody(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
              />
            </div>
            <button
              type="submit"
              disabled={busy}
              className="w-full py-2.5 rounded-lg bg-[#4338CA] hover:bg-[#3730A3] disabled:opacity-60 text-white text-sm font-medium"
            >
              {busy ? 'Saving...' : 'Save Reflection Note'}
            </button>
          </form>
        )}

        {(tab === 'tasks' || tab === 'chat') && (!isAuthenticated || !token) && (
          <div className="p-4 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-center space-y-3">
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Authorize your Google account to connect {tab === 'tasks' ? 'Google Tasks' : 'Google Chat'}.
            </p>
            <button
              type="button"
              onClick={onSignIn}
              className="px-4 py-2 rounded-lg bg-[#4338CA] text-white text-xs font-medium"
            >
              Sign in with Google
            </button>
          </div>
        )}

        {tab === 'tasks' && isAuthenticated && token && (
          <form onSubmit={handleCreateTask} className="space-y-3">
            <div>
              <label htmlFor="task-list-select" className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Task List
              </label>
              <select
                id="task-list-select"
                value={selectedListId}
                onChange={(e) => setSelectedListId(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
              >
                <option value="@default">Default Task List</option>
                {taskLists.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.title}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="task-title-input" className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Task Title
              </label>
              <input
                id="task-title-input"
                type="text"
                required
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label htmlFor="task-due-input" className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Due Date (Optional)
              </label>
              <input
                id="task-due-input"
                type="date"
                value={taskDue}
                onChange={(e) => setTaskDue(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
              />
            </div>
            <button
              type="submit"
              disabled={busy}
              className="w-full py-2.5 rounded-lg bg-[#4338CA] hover:bg-[#3730A3] disabled:opacity-60 text-white text-sm font-medium"
            >
              {busy ? 'Creating Task...' : 'Add to Google Tasks'}
            </button>
          </form>
        )}

        {tab === 'chat' && isAuthenticated && token && (
          <div className="space-y-3">
            <div>
              <label htmlFor="chat-space-select" className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Destination Space
              </label>
              <select
                id="chat-space-select"
                value={selectedSpace}
                onChange={(e) => setSelectedSpace(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
              >
                {chatSpaces.length === 0 ? (
                  <option value="">No spaces loaded</option>
                ) : (
                  chatSpaces.map((s) => (
                    <option key={s.name} value={s.name}>
                      {s.displayName || s.name}
                    </option>
                  ))
                )}
              </select>
            </div>
            <div>
              <label htmlFor="chat-msg-input" className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                Message
              </label>
              <textarea
                id="chat-msg-input"
                rows={3}
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
              />
            </div>

            {!confirmChatSend ? (
              <button
                type="button"
                disabled={!selectedSpace || !chatMessage.trim()}
                onClick={() => setConfirmChatSend(true)}
                className="w-full py-2.5 rounded-lg bg-[#4338CA] hover:bg-[#3730A3] disabled:opacity-50 text-white text-sm font-medium"
              >
                Review &amp; Send to Google Chat
              </button>
            ) : (
              <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30 space-y-2.5">
                <p className="text-xs font-medium text-amber-900 dark:text-amber-200">
                  Confirm posting this quote message to the selected Google Chat space?
                </p>
                <div className="flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setConfirmChatSend(false)}
                    className="px-3 py-1.5 rounded-md border border-slate-200 dark:border-slate-700 text-xs font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={handleSendChat}
                    className="px-3 py-1.5 rounded-md bg-[#4338CA] text-white text-xs font-medium"
                  >
                    {busy ? 'Sending...' : 'Confirm Send'}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
