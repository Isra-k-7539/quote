import React, { useState } from 'react';
import {
  CheckSquare,
  CloudUpload,
  ExternalLink,
  LogOut,
  MessageSquare,
  NotebookPen,
  RefreshCw,
  Trash2,
} from 'lucide-react';
import type { QuoteNote, UserProfile } from '../types/quoteverse.ts';
import {
  fetchGoogleChatSpacesApi,
  fetchGoogleTaskListsApi,
  type GoogleChatSpace,
  type GoogleTaskList,
} from '../services/apiClient.ts';
import { getProjectId, getWorkspaceAccessToken } from '../lib/firebase.ts';

interface ProfileWorkspaceViewProps {
  isAuthenticated: boolean;
  hasWorkspaceToken: boolean;
  profile: UserProfile | null;
  notes: QuoteNote[];
  historyCount: number;
  favoritesCount: number;
  onGoogleSignIn: () => Promise<void>;
  onSignOut: () => Promise<void>;
  onMigrateGuest: () => Promise<number>;
  onDeleteNote: (noteId: string) => void;
}

export const ProfileWorkspaceView: React.FC<ProfileWorkspaceViewProps> = ({
  isAuthenticated,
  hasWorkspaceToken,
  profile,
  notes,
  historyCount,
  favoritesCount,
  onGoogleSignIn,
  onSignOut,
  onMigrateGuest,
  onDeleteNote,
}) => {
  const defaultAvatar = '/src/assets/images/quoteverse_default_avatar_1795431221240.jpg';
  const [signingIn, setSigningIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [migrating, setMigrating] = useState(false);
  const [migrateMsg, setMigrateMsg] = useState<string | null>(null);

  const [taskLists, setTaskLists] = useState<GoogleTaskList[]>([]);
  const [tasksLoading, setTasksLoading] = useState(false);
  const [tasksError, setTasksError] = useState<string | null>(null);

  const [chatSpaces, setChatSpaces] = useState<GoogleChatSpace[]>([]);
  const [chatLoading, setChatLoading] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);

  const projectId = getProjectId();

  const handleSignIn = async () => {
    setSigningIn(true);
    setAuthError(null);
    try {
      await onGoogleSignIn();
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Google Sign-In failed.');
    } finally {
      setSigningIn(false);
    }
  };

  const handleMigrate = async () => {
    setMigrating(true);
    setMigrateMsg(null);
    try {
      const count = await onMigrateGuest();
      setMigrateMsg(
        count > 0
          ? `Synced ${count} guest quotes to your Firestore archive.`
          : 'Your cloud archive already has saved history.'
      );
    } catch (err) {
      setMigrateMsg(err instanceof Error ? err.message : 'Migration failed.');
    } finally {
      setMigrating(false);
    }
  };

  const handleLoadTaskLists = async () => {
    const token = getWorkspaceAccessToken();
    if (!token) {
      setTasksError('Please sign in with Google again to authorize a fresh Google Tasks session token.');
      return;
    }
    setTasksLoading(true);
    setTasksError(null);
    try {
      const items = await fetchGoogleTaskListsApi(token);
      setTaskLists(items);
    } catch (err: unknown) {
      const msg =
        (err as { response?: { data?: { error?: string } } })?.response?.data?.error ||
        (err instanceof Error ? err.message : 'Could not load Google Tasks.');
      setTasksError(msg);
    } finally {
      setTasksLoading(false);
    }
  };

  const handleLoadChatSpaces = async () => {
    const token = getWorkspaceAccessToken();
    if (!token) {
      setChatError('Please sign in with Google again to authorize a fresh Google Chat session token.');
      return;
    }
    setChatLoading(true);
    setChatError(null);
    try {
      const spaces = await fetchGoogleChatSpacesApi(token);
      setChatSpaces(spaces);
    } catch (err: unknown) {
      const msg =
        (err as { response?: { data?: { error?: string } } })?.response?.data?.error ||
        (err instanceof Error ? err.message : 'Could not load Google Chat spaces.');
      setChatError(msg);
    } finally {
      setChatLoading(false);
    }
  };

  return (
    <div className="max-w-5xl space-y-6">
      {/* Account Card */}
      <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <img
            src={profile?.photoURL || defaultAvatar}
            alt={profile?.displayName || 'QuoteVerse Reader'}
            referrerPolicy="no-referrer"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = defaultAvatar;
            }}
            className="w-16 h-16 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
          />
          <div className="space-y-1">
            <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
              {isAuthenticated ? profile?.displayName || 'Authenticated Reader' : 'Guest Reader Mode'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isAuthenticated
                ? `${profile?.email} · Cloud Firestore Sync Active`
                : 'Quotes are saved locally in this browser. Sign in with Google for cloud persistence and Workspace sync.'}
            </p>
            <div className="flex items-center gap-3 pt-1 text-xs font-mono tabular-nums text-slate-600 dark:text-slate-300">
              <span>{historyCount} in history</span>
              <span aria-hidden="true">·</span>
              <span>{favoritesCount} favorites</span>
              <span aria-hidden="true">·</span>
              <span>{notes.length} notes</span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {!isAuthenticated || !hasWorkspaceToken ? (
            <button
              type="button"
              onClick={handleSignIn}
              disabled={signingIn}
              className="inline-flex items-center gap-3 px-4 py-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 48 48" aria-hidden="true">
                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
              </svg>
              <span>{isAuthenticated ? 'Authorize Workspace' : 'Sign in with Google'}</span>
            </button>
          ) : null}

          {isAuthenticated && (
            <>
              <button
                type="button"
                onClick={handleMigrate}
                disabled={migrating}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
              >
                <CloudUpload className="w-4 h-4 text-[#4338CA]" />
                <span>{migrating ? 'Syncing...' : 'Import Guest Quotes'}</span>
              </button>
              <button
                type="button"
                onClick={onSignOut}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-500/10 whitespace-nowrap shrink-0"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </>
          )}
        </div>
      </section>

      {authError && (
        <div role="alert" className="p-4 rounded-xl bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/30 text-sm text-rose-700 dark:text-rose-200">
          {authError}
        </div>
      )}

      {migrateMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30 text-xs text-emerald-700 dark:text-emerald-200">
          {migrateMsg}
        </div>
      )}

      {/* Google Tasks & Google Chat Live Workspace Connectors */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-[#4338CA]" />
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                Google Tasks Lists
              </h3>
            </div>
            <button
              type="button"
              onClick={handleLoadTaskLists}
              disabled={tasksLoading}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${tasksLoading ? 'animate-spin' : ''}`} />
              <span>Fetch Task Lists</span>
            </button>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400">
            Turn any quote into an actionable reminder using the Workspace button on any quote card.
          </p>

          {tasksError && (
            <p className="text-xs text-rose-600 dark:text-rose-400">{tasksError}</p>
          )}

          {taskLists.length > 0 && (
            <ul className="divide-y divide-slate-100 dark:divide-slate-700/60 text-sm">
              {taskLists.map((list) => (
                <li key={list.id} className="py-2 flex items-center justify-between">
                  <span className="text-slate-800 dark:text-slate-200">{list.title}</span>
                  <span className="font-mono text-xs text-slate-400">{list.id.slice(0, 10)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-[#8B5CF6]" />
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                Google Chat Spaces
              </h3>
            </div>
            <button
              type="button"
              onClick={handleLoadChatSpaces}
              disabled={chatLoading}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${chatLoading ? 'animate-spin' : ''}`} />
              <span>Fetch Spaces</span>
            </button>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400">
            Share quotes to team spaces. Note: Google Chat requires a Business/Enterprise Workspace account and Chat app setup in Cloud Console.
          </p>

          {chatError && (
            <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30 text-xs text-amber-800 dark:text-amber-200 space-y-1.5">
              <p>{chatError}</p>
              <a
                href={`https://console.cloud.google.com/apis/api/chat.googleapis.com/hangouts-chat?project=${projectId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 font-medium underline"
              >
                Open Google Chat API Configuration
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}

          {chatSpaces.length > 0 && (
            <ul className="divide-y divide-slate-100 dark:divide-slate-700/60 text-sm">
              {chatSpaces.map((sp) => (
                <li key={sp.name} className="py-2 flex items-center justify-between">
                  <span className="text-slate-800 dark:text-slate-200">
                    {sp.displayName || sp.name}
                  </span>
                  <span className="font-mono text-xs text-slate-400">{sp.spaceType || 'SPACE'}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* Quote Reflection Notes (Keep-compatible) */}
      <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <NotebookPen className="w-4 h-4 text-amber-500" />
            <h3 className="text-base font-semibold text-slate-900 dark:text-white">
              Quote Reflection Notes
            </h3>
          </div>
          <a
            href="https://keep.google.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs font-medium text-[#4338CA] dark:text-indigo-300 hover:underline"
          >
            Open Google Keep Web
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Your personal quote reflections are persisted in QuoteVerse (Firestore / local archive) because the Google Keep API is enterprise-only with domain-wide delegation.
        </p>

        {notes.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400 py-4">
            No reflection notes yet. Click “Workspace” on any quote card to write a reflection note.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {notes.map((note) => (
              <div
                key={note.id}
                className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700/70 space-y-2 flex flex-col justify-between"
              >
                <div className="space-y-1.5">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="text-sm font-semibold text-slate-900 dark:text-white">
                      {note.title}
                    </h4>
                    <button
                      type="button"
                      onClick={() => onDeleteNote(note.id)}
                      aria-label={`Delete note ${note.title}`}
                      className="p-1 text-slate-400 hover:text-rose-600"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                    {note.body}
                  </p>
                </div>
                {note.quoteText && (
                  <p className="font-serif text-xs italic text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-200/70 dark:border-slate-800">
                    “{note.quoteText}” — {note.author}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
