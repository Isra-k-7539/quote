import React from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ArrowRight, Heart, Sparkles, Star } from 'lucide-react';
import type {
  AnalyticsSummary,
  HistoryEntry,
  NavSection,
  Quote,
} from '../types/quoteverse.ts';

interface DashboardViewProps {
  userName: string;
  dailyQuote: Quote | null;
  dailyQuoteLoading: boolean;
  analytics: AnalyticsSummary;
  recentHistory: HistoryEntry[];
  isFavorite: (quoteId: string) => boolean;
  onToggleFavorite: (entry: HistoryEntry) => void;
  onNavigate: (section: NavSection) => void;
  onQuickGenerate: () => void;
  onOpenStudio: (quote: { quoteId: string; quoteText: string; author: string; category: string }) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  userName,
  dailyQuote,
  dailyQuoteLoading,
  analytics,
  recentHistory,
  isFavorite,
  onToggleFavorite,
  onNavigate,
  onQuickGenerate,
  onOpenStudio,
}) => {
  const backdropImg = '/src/assets/images/quoteverse_editorial_backdrop_1795431221192.jpg';

  return (
    <div className="space-y-8">
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-5 bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 sm:p-8 flex flex-col justify-between gap-6">
          <div className="space-y-3">
            <p className="text-xs font-medium text-[#4338CA] dark:text-indigo-300 tracking-wide">
              Personal Quote Archive
            </p>
            <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-slate-900 dark:text-white leading-tight [text-wrap:balance]">
              Welcome back, {userName}
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-prose">
              Discover verified quotes from live literary APIs, preserve every discovery in your chronological history, and curate collections with AI-grounded context.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={onQuickGenerate}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#4338CA] hover:bg-[#3730A3] text-white text-sm font-medium transition-colors whitespace-nowrap shrink-0"
            >
              <Sparkles className="w-4 h-4" />
              Generate Random Quote
            </button>
            <button
              type="button"
              onClick={() => onNavigate('history')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 text-sm font-medium transition-colors whitespace-nowrap shrink-0"
            >
              Explore History
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="lg:col-span-7 relative overflow-hidden rounded-xl border border-slate-200 dark:border-slate-700/80 min-h-[260px] flex flex-col justify-between p-6 sm:p-8 text-white bg-slate-900">
          <img
            src={backdropImg}
            alt="Quiet architectural library desk in morning light"
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover opacity-55"
          />
          <div
            className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/65 to-slate-950/45"
            aria-hidden="true"
          />

          <div className="relative z-10 flex items-center justify-between gap-4">
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-300">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              Quote of the Day
            </span>
            {dailyQuote && (
              <span className="text-xs text-slate-300 font-mono tabular-nums">
                {dailyQuote.category}
              </span>
            )}
          </div>

          <div className="relative z-10 my-4 space-y-3">
            {dailyQuoteLoading ? (
              <div className="space-y-2 animate-pulse">
                <div className="h-6 bg-white/20 rounded w-5/6" />
                <div className="h-6 bg-white/20 rounded w-2/3" />
              </div>
            ) : dailyQuote ? (
              <>
                <blockquote className="font-serif text-xl sm:text-2xl leading-relaxed text-white">
                  “{dailyQuote.quoteText}”
                </blockquote>
                <p className="text-sm font-medium text-slate-200">— {dailyQuote.author}</p>
              </>
            ) : (
              <p className="text-sm text-slate-300">Daily quote unavailable right now.</p>
            )}
          </div>

          {dailyQuote && (
            <div className="relative z-10 flex items-center gap-3">
              <button
                type="button"
                onClick={() =>
                  onOpenStudio({
                    quoteId: dailyQuote.id,
                    quoteText: dailyQuote.quoteText,
                    author: dailyQuote.author,
                    category: dailyQuote.category,
                  })
                }
                className="px-3.5 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 backdrop-blur-xs text-xs font-medium text-white transition-colors whitespace-nowrap shrink-0"
              >
                Create Poster
              </button>
              <button
                type="button"
                onClick={() => onNavigate('categories')}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium text-slate-200 hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                Browse Categories
              </button>
            </div>
          )}
        </div>
      </section>

      <section aria-label="Quote Statistics" className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Total Quotes Generated
          </p>
          <p className="mt-2 text-2xl sm:text-3xl font-semibold font-mono tabular-nums text-slate-900 dark:text-white">
            {analytics.totalGenerated}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Saved chronologically
          </p>
        </div>

        <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Total Favorite Quotes
          </p>
          <p className="mt-2 text-2xl sm:text-3xl font-semibold font-mono tabular-nums text-slate-900 dark:text-white">
            {analytics.totalFavorites}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Curated keepsakes
          </p>
        </div>

        <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Categories Explored
          </p>
          <p className="mt-2 text-2xl sm:text-3xl font-semibold font-mono tabular-nums text-slate-900 dark:text-white">
            {analytics.uniqueCategories}
            <span className="text-sm font-normal text-slate-400"> / 14</span>
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Across curated themes
          </p>
        </div>

        <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Reflection Notes
          </p>
          <p className="mt-2 text-2xl sm:text-3xl font-semibold font-mono tabular-nums text-slate-900 dark:text-white">
            {analytics.totalNotes}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Personal annotations
          </p>
        </div>
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                Weekly Reading Activity
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Quotes generated and favorited over the last 7 days
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('analytics')}
              className="text-xs font-medium text-[#4338CA] dark:text-indigo-300 hover:underline whitespace-nowrap shrink-0"
            >
              Full Analytics
            </button>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={analytics.weeklySeries} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="qvIndigo" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4338CA" stopOpacity={0.28} />
                    <stop offset="95%" stopColor="#4338CA" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="qvGold" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#F59E0B" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#94A3B8" strokeOpacity={0.2} />
                <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#64748B' }} axisLine={false} tickLine={false} />
                <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: '#64748B' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderRadius: '8px',
                    border: '1px solid #CBD5E1',
                    fontSize: '12px',
                    color: '#1E293B',
                  }}
                  labelStyle={{ color: '#0F172A', fontWeight: 600 }}
                />
                <Area
                  type="monotone"
                  dataKey="generated"
                  name="Generated"
                  stroke="#4338CA"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#qvIndigo)"
                />
                <Area
                  type="monotone"
                  dataKey="favorites"
                  name="Favorited"
                  stroke="#F59E0B"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#qvGold)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-5 bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                Most Popular Categories
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Distribution across your generated quotes
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('categories')}
              className="text-xs font-medium text-[#4338CA] dark:text-indigo-300 hover:underline whitespace-nowrap shrink-0"
            >
              View All 14
            </button>
          </div>

          <div className="h-64 w-full">
            {analytics.categoryBreakdown.length === 0 ? (
              <div className="h-full flex items-center justify-center text-sm text-slate-500 dark:text-slate-400">
                Generate quotes to see category insights.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={analytics.categoryBreakdown.slice(0, 6)}
                  layout="vertical"
                  margin={{ top: 4, right: 16, left: 16, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#94A3B8" strokeOpacity={0.18} horizontal={false} />
                  <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11, fill: '#64748B' }} axisLine={false} tickLine={false} />
                  <YAxis
                    dataKey="category"
                    type="category"
                    width={96}
                    tick={{ fontSize: 11, fill: '#64748B' }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#FFFFFF',
                      borderRadius: '8px',
                      border: '1px solid #CBD5E1',
                      fontSize: '12px',
                      color: '#1E293B',
                    }}
                    labelStyle={{ color: '#0F172A', fontWeight: 600 }}
                  />
                  <Bar dataKey="count" name="Quotes" fill="#8B5CF6" radius={[0, 6, 6, 0]} barSize={18} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </section>

      <section className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-700/80 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-semibold text-slate-900 dark:text-white">
              Recent Quote History
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Your latest fetched and saved quotes
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('history')}
            className="text-xs font-medium text-[#4338CA] dark:text-indigo-300 hover:underline whitespace-nowrap shrink-0"
          >
            Open Full History
          </button>
        </div>

        {recentHistory.length === 0 ? (
          <div className="py-10 text-center space-y-3">
            <p className="text-sm text-slate-500 dark:text-slate-400">
              No quotes generated yet. Fetch your first quote to start your personal archive.
            </p>
            <button
              type="button"
              onClick={onQuickGenerate}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#4338CA] text-white text-sm font-medium hover:bg-[#3730A3]"
            >
              <Sparkles className="w-4 h-4" />
              Generate First Quote
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-700/60">
            {recentHistory.slice(0, 5).map((item) => {
              const fav = isFavorite(item.quoteId);
              return (
                <div
                  key={item.id}
                  className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1 min-w-0">
                    <p className="font-serif text-sm sm:text-base text-slate-900 dark:text-slate-100">
                      “{item.quoteText}”
                    </p>
                    <div className="flex flex-wrap items-center gap-x-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className="font-medium text-slate-700 dark:text-slate-300">
                        {item.author}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{item.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{item.source}</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onToggleFavorite(item)}
                    aria-label={fav ? `Unfavorite quote by ${item.author}` : `Favorite quote by ${item.author}`}
                    className={`self-start sm:self-center inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                      fav
                        ? 'bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-500/30'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Heart className={`w-3.5 h-3.5 ${fav ? 'fill-current' : ''}`} />
                    <span>{fav ? 'Saved' : 'Save'}</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
