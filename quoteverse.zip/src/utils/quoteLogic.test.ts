import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildCanonicalQuoteId,
  buildCsvExport,
  buildJsonExport,
  computeAnalyticsSummary,
  filterHistoryEntries,
  getMoodRecommendedCategories,
  sanitizeId,
  truncateForBlueprint,
} from './quoteLogic';
import type { ActivityEntry, FavoriteEntry, HistoryEntry, QuoteNote } from '../types/quoteverse';

const sampleHistory: HistoryEntry[] = [
  {
    id: 'h_1',
    userId: 'u_1',
    quoteId: 'q_1',
    quoteText: 'Simplicity is prerequisite for reliability.',
    author: 'Edsger W. Dijkstra',
    category: 'Technology',
    source: 'QuoteVerse Archive',
    mood: 'Focused',
    isFavorite: true,
    generatedAt: '2026-11-23T10:00:00.000Z',
  },
  {
    id: 'h_2',
    userId: 'u_1',
    quoteId: 'q_2',
    quoteText: 'We suffer more often in imagination than in reality.',
    author: 'Seneca',
    category: 'Philosophy',
    source: 'ZenQuotes',
    mood: 'Stressed',
    isFavorite: false,
    generatedAt: '2026-11-22T09:00:00.000Z',
  },
  {
    id: 'h_3',
    userId: 'u_1',
    quoteId: 'q_3',
    quoteText: 'Creativity takes courage.',
    author: 'Henri Matisse',
    category: 'Creativity',
    source: 'DummyJSON',
    mood: 'Motivated',
    isFavorite: true,
    generatedAt: '2026-11-20T14:30:00.000Z',
  },
];

test('buildCanonicalQuoteId produces deterministic valid Firestore IDs', () => {
  const id1 = buildCanonicalQuoteId('Creativity takes courage.', 'Henri Matisse');
  const id2 = buildCanonicalQuoteId('  creativity takes courage. ', 'henri matisse');
  assert.equal(id1, id2);
  assert.match(id1, /^[a-zA-Z0-9_-]+$/);
});

test('sanitizeId strips invalid characters and bounds length to 128', () => {
  const dirty = 'bad/id with spaces!' + 'a'.repeat(150);
  const clean = sanitizeId(dirty);
  assert.ok(clean.length <= 128);
  assert.match(clean, /^[a-zA-Z0-9_-]+$/);
});

test('truncateForBlueprint trims and enforces maxLength', () => {
  assert.equal(truncateForBlueprint('  hello world  ', 5), 'hello');
});

test('filterHistoryEntries filters by search, category, author, and sorts correctly', () => {
  const byCategory = filterHistoryEntries(sampleHistory, { category: 'Philosophy' });
  assert.equal(byCategory.length, 1);
  assert.equal(byCategory[0].author, 'Seneca');

  const bySearch = filterHistoryEntries(sampleHistory, { search: 'reliability' });
  assert.equal(bySearch.length, 1);
  assert.equal(bySearch[0].id, 'h_1');

  const oldestFirst = filterHistoryEntries(sampleHistory, { sort: 'oldest' });
  assert.equal(oldestFirst[0].id, 'h_3');
  assert.equal(oldestFirst[2].id, 'h_1');
});

test('buildCsvExport escapes commas and quotes properly', () => {
  const csv = buildCsvExport([
    {
      ...sampleHistory[0],
      quoteText: 'Hello, "world"',
    },
  ]);
  const lines = csv.split('\n');
  assert.equal(lines.length, 2);
  assert.ok(lines[1].includes('"Hello, ""world"""'));
});

test('buildJsonExport outputs valid JSON array', () => {
  const json = buildJsonExport(sampleHistory);
  const parsed = JSON.parse(json);
  assert.equal(parsed.length, 3);
  assert.equal(parsed[0].author, 'Edsger W. Dijkstra');
});

test('computeAnalyticsSummary aggregates counts and 7-day series accurately', () => {
  const favorites: FavoriteEntry[] = [
    {
      id: 'f_1',
      userId: 'u_1',
      quoteId: 'q_1',
      quoteText: sampleHistory[0].quoteText,
      author: sampleHistory[0].author,
      category: sampleHistory[0].category,
      source: sampleHistory[0].source,
      collectionId: '',
      createdAt: '2026-11-23T10:05:00.000Z',
    },
  ];
  const activity: ActivityEntry[] = [];
  const notes: QuoteNote[] = [];

  const summary = computeAnalyticsSummary(
    sampleHistory,
    favorites,
    activity,
    notes,
    new Date('2026-11-23T12:00:00.000Z')
  );

  assert.equal(summary.totalGenerated, 3);
  assert.equal(summary.totalFavorites, 1);
  assert.equal(summary.uniqueCategories, 3);
  assert.equal(summary.weeklySeries.length, 7);
  assert.equal(summary.weeklySeries[6].generated, 1);
  assert.equal(summary.weeklySeries[6].favorites, 1);
});

test('getMoodRecommendedCategories maps moods to domain categories', () => {
  const cats = getMoodRecommendedCategories('Stressed');
  assert.ok(cats.includes('Philosophy'));
  assert.deepEqual(getMoodRecommendedCategories(''), []);
});
