import type {
  ActivityEntry,
  AnalyticsSummary,
  FavoriteEntry,
  HistoryEntry,
  MoodOption,
  QuoteNote,
} from '../types/quoteverse.ts';
import { ALL_MOODS } from '../data/quotesCatalog.ts';

export function buildCanonicalQuoteId(quoteText: string, author: string): string {
  const normalized = `${quoteText.trim().toLowerCase()}::${author.trim().toLowerCase()}`;
  let hash1 = 2166136261;
  let hash2 = 5381;
  for (let i = 0; i < normalized.length; i++) {
    const code = normalized.charCodeAt(i);
    hash1 ^= code;
    hash1 = Math.imul(hash1, 16777619);
    hash2 = ((hash2 << 5) + hash2) ^ code;
  }
  const partA = (hash1 >>> 0).toString(36);
  const partB = (hash2 >>> 0).toString(36);
  return `q_${partA}_${partB}`;
}

export function sanitizeId(raw: string): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 128);
  return cleaned.length > 0 ? cleaned : `id_${Date.now()}`;
}

export function truncateForBlueprint(value: string, maxLength: number): string {
  const trimmed = value.trim();
  if (trimmed.length <= maxLength) return trimmed;
  return trimmed.slice(0, maxLength);
}

export function getMoodRecommendedCategories(mood: MoodOption | ''): string[] {
  if (!mood) return [];
  const found = ALL_MOODS.find((item) => item.mood === mood);
  return found ? found.categories : [];
}

export interface HistoryFilterOptions {
  search?: string;
  category?: string;
  author?: string;
  dateFrom?: string;
  dateTo?: string;
  sort?: 'newest' | 'oldest';
}

export function filterHistoryEntries(
  entries: HistoryEntry[],
  options: HistoryFilterOptions
): HistoryEntry[] {
  const search = (options.search ?? '').trim().toLowerCase();
  const category = (options.category ?? '').trim().toLowerCase();
  const author = (options.author ?? '').trim().toLowerCase();
  const dateFrom = options.dateFrom ? new Date(options.dateFrom).getTime() : null;
  const dateTo = options.dateTo ? new Date(`${options.dateTo}T23:59:59.999Z`).getTime() : null;

  const filtered = entries.filter((entry) => {
    if (category && category !== 'all' && entry.category.toLowerCase() !== category) {
      return false;
    }
    if (author && !entry.author.toLowerCase().includes(author)) {
      return false;
    }
    if (search) {
      const hay = `${entry.quoteText} ${entry.author} ${entry.category} ${entry.source}`.toLowerCase();
      if (!hay.includes(search)) {
        return false;
      }
    }
    const ts = new Date(entry.generatedAt).getTime();
    if (dateFrom !== null && !Number.isNaN(dateFrom) && ts < dateFrom) {
      return false;
    }
    if (dateTo !== null && !Number.isNaN(dateTo) && ts > dateTo) {
      return false;
    }
    return true;
  });

  const sortMode = options.sort ?? 'newest';
  return [...filtered].sort((a, b) => {
    const ta = new Date(a.generatedAt).getTime();
    const tb = new Date(b.generatedAt).getTime();
    return sortMode === 'oldest' ? ta - tb : tb - ta;
  });
}

function escapeCsvCell(value: string): string {
  const str = String(value ?? '');
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function buildCsvExport(entries: HistoryEntry[]): string {
  const headers = ['ID', 'Quote', 'Author', 'Category', 'Source', 'Mood', 'Favorite', 'Generated At'];
  const rows = entries.map((e) =>
    [
      escapeCsvCell(e.id),
      escapeCsvCell(e.quoteText),
      escapeCsvCell(e.author),
      escapeCsvCell(e.category),
      escapeCsvCell(e.source),
      escapeCsvCell(e.mood || 'General'),
      e.isFavorite ? 'Yes' : 'No',
      escapeCsvCell(e.generatedAt),
    ].join(',')
  );
  return [headers.join(','), ...rows].join('\n');
}

export function buildJsonExport(entries: HistoryEntry[]): string {
  return JSON.stringify(
    entries.map((e) => ({
      id: e.id,
      quoteId: e.quoteId,
      quoteText: e.quoteText,
      author: e.author,
      category: e.category,
      source: e.source,
      mood: e.mood,
      isFavorite: e.isFavorite,
      generatedAt: e.generatedAt,
    })),
    null,
    2
  );
}

export function computeAnalyticsSummary(
  history: HistoryEntry[],
  favorites: FavoriteEntry[],
  activity: ActivityEntry[],
  notes: QuoteNote[],
  referenceDate: Date = new Date()
): AnalyticsSummary {
  const categorySet = new Set<string>();
  const categoryCounts = new Map<string, number>();
  const moodCounts = new Map<string, number>();

  for (const h of history) {
    if (h.category) {
      categorySet.add(h.category);
      categoryCounts.set(h.category, (categoryCounts.get(h.category) ?? 0) + 1);
    }
    if (h.mood) {
      moodCounts.set(h.mood, (moodCounts.get(h.mood) ?? 0) + 1);
    }
  }

  for (const a of activity) {
    if (a.mood && !history.length) {
      moodCounts.set(a.mood, (moodCounts.get(a.mood) ?? 0) + 1);
    }
  }

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const weeklySeries: { day: string; date: string; generated: number; favorites: number }[] = [];

  for (let offset = 6; offset >= 0; offset--) {
    const d = new Date(referenceDate);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - offset);
    const isoDay = d.toISOString().slice(0, 10);

    const genCount = history.filter((h) => h.generatedAt.slice(0, 10) === isoDay).length;
    const favCount = favorites.filter((f) => f.createdAt.slice(0, 10) === isoDay).length;

    weeklySeries.push({
      day: dayNames[d.getDay()],
      date: isoDay,
      generated: genCount,
      favorites: favCount,
    });
  }

  const monthlySeries: { week: string; generated: number; favorites: number }[] = [];
  for (let w = 3; w >= 0; w--) {
    const end = new Date(referenceDate);
    end.setHours(23, 59, 59, 999);
    end.setDate(end.getDate() - w * 7);
    const start = new Date(end);
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - 6);

    const startMs = start.getTime();
    const endMs = end.getTime();

    const genCount = history.filter((h) => {
      const t = new Date(h.generatedAt).getTime();
      return t >= startMs && t <= endMs;
    }).length;
    const favCount = favorites.filter((f) => {
      const t = new Date(f.createdAt).getTime();
      return t >= startMs && t <= endMs;
    }).length;

    monthlySeries.push({
      week: `Week ${4 - w}`,
      generated: genCount,
      favorites: favCount,
    });
  }

  const categoryBreakdown = Array.from(categoryCounts.entries())
    .map(([category, count]) => ({ category, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  const moodBreakdown = Array.from(moodCounts.entries())
    .map(([mood, count]) => ({ mood, count }))
    .sort((a, b) => b.count - a.count);

  return {
    totalGenerated: history.length,
    totalFavorites: favorites.length,
    uniqueCategories: categorySet.size,
    totalNotes: notes.length,
    weeklySeries,
    monthlySeries,
    categoryBreakdown,
    moodBreakdown,
  };
}
