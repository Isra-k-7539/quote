import axios from 'axios';
import type {
  ApiProviderOption,
  CategoryInfo,
  ChatMessage,
  GroundedQuoteContext,
  GroundingSource,
  Quote,
} from '../types/quoteverse.ts';

const api = axios.create({
  baseURL: '/api',
  timeout: 15000,
});

export async function fetchRandomQuoteApi(params: {
  category?: string;
  provider?: ApiProviderOption;
  excludeIds?: string[];
}): Promise<{ quote: Quote; fallbackUsed: boolean; providerError?: string }> {
  const res = await api.get('/quotes/random', {
    params: {
      category: params.category && params.category !== 'All' ? params.category : undefined,
      provider: params.provider || 'auto',
      exclude: params.excludeIds?.slice(0, 20).join(','),
    },
  });
  return res.data;
}

export async function fetchDailyQuoteApi(): Promise<{ quote: Quote; date: string }> {
  const res = await api.get('/quotes/daily');
  return res.data;
}

export async function fetchCategoriesApi(): Promise<CategoryInfo[]> {
  const res = await api.get('/categories');
  return res.data.categories;
}

export async function fetchCategoryQuotesApi(categoryName: string): Promise<Quote[]> {
  const res = await api.get(`/categories/${encodeURIComponent(categoryName)}/quotes`);
  return res.data.quotes;
}

export async function fetchAiMoodRecommendationApi(params: {
  mood: string;
  interest?: string;
}): Promise<{ quote: Quote; whyItFits: string }> {
  const res = await api.post('/ai/recommend', params);
  return res.data;
}

export async function fetchGroundedQuoteContextApi(params: {
  quoteText: string;
  author: string;
}): Promise<GroundedQuoteContext> {
  const res = await api.post('/ai/ground', params);
  return res.data;
}

export async function sendAiChatMessageApi(params: {
  message: string;
  history: Pick<ChatMessage, 'role' | 'text'>[];
  activeQuote?: { quoteText: string; author: string; category: string } | null;
}): Promise<{ reply: string; sources: GroundingSource[] }> {
  const res = await api.post('/ai/chat', params);
  return res.data;
}

export interface GoogleTaskList {
  id: string;
  title: string;
}

export interface GoogleChatSpace {
  name: string;
  displayName?: string;
  spaceType?: string;
}

export async function fetchGoogleTaskListsApi(accessToken: string): Promise<GoogleTaskList[]> {
  const res = await api.get('/workspace/tasks/lists', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  return res.data.items || [];
}

export async function createGoogleTaskApi(
  accessToken: string,
  payload: { listId: string; title: string; notes: string; due?: string }
): Promise<{ id: string; title: string }> {
  const res = await api.post('/workspace/tasks', payload, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  return res.data;
}

export async function fetchGoogleChatSpacesApi(accessToken: string): Promise<GoogleChatSpace[]> {
  const res = await api.get('/workspace/chat/spaces', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  return res.data.spaces || [];
}

export async function sendGoogleChatMessageApi(
  accessToken: string,
  payload: { spaceName: string; text: string }
): Promise<{ name: string }> {
  const res = await api.post('/workspace/chat/messages', payload, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  return res.data;
}
