import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  type Timestamp,
  type Unsubscribe,
} from 'firebase/firestore';
import type { User } from 'firebase/auth';
import { db, handleFirestoreError, OperationType } from '../lib/firebase.ts';
import type {
  ActivityEntry,
  ActivityType,
  FavoriteEntry,
  HistoryEntry,
  Quote,
  QuoteCollection,
  QuoteNote,
  UserProfile,
} from '../types/quoteverse.ts';
import { CURATED_QUOTES } from '../data/quotesCatalog.ts';
import { buildCanonicalQuoteId, sanitizeId, truncateForBlueprint } from '../utils/quoteLogic.ts';

function toIsoString(val: unknown): string {
  if (!val) return new Date().toISOString();
  if (typeof val === 'string') return val;
  if (typeof (val as Timestamp).toDate === 'function') {
    return (val as Timestamp).toDate().toISOString();
  }
  return new Date().toISOString();
}

// Guest Mode Local Storage Keys (used ONLY when unauthenticated)
const GUEST_HISTORY_KEY = 'quoteverse_guest_history_v1';
const GUEST_FAVORITES_KEY = 'quoteverse_guest_favorites_v1';
const GUEST_COLLECTIONS_KEY = 'quoteverse_guest_collections_v1';
const GUEST_NOTES_KEY = 'quoteverse_guest_notes_v1';
const GUEST_ACTIVITY_KEY = 'quoteverse_guest_activity_v1';
const GUEST_SETTINGS_KEY = 'quoteverse_guest_settings_v1';

function readGuestJson<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeGuestJson<T>(key: string, value: T): void {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Ignore storage quota errors in restricted sandboxes
  }
}

export function getSeededGuestHistory(): HistoryEntry[] {
  const existing = readGuestJson<HistoryEntry[] | null>(GUEST_HISTORY_KEY, null);
  if (existing && existing.length > 0) return existing;

  const now = Date.now();
  const seeds = [
    { q: CURATED_QUOTES[24], hoursAgo: 2, mood: 'Stressed', fav: true },
    { q: CURATED_QUOTES[36], hoursAgo: 18, mood: 'Focused', fav: true },
    { q: CURATED_QUOTES[0], hoursAgo: 42, mood: 'Motivated', fav: false },
    { q: CURATED_QUOTES[28], hoursAgo: 70, mood: 'Hopeful', fav: false },
    { q: CURATED_QUOTES[44], hoursAgo: 98, mood: 'Confident', fav: true },
  ];

  const initial: HistoryEntry[] = seeds.map((s, idx) => ({
    id: `seed_hist_${idx + 1}`,
    userId: 'guest',
    quoteId: buildCanonicalQuoteId(s.q.quoteText, s.q.author),
    quoteText: s.q.quoteText,
    author: s.q.author,
    category: s.q.category,
    source: s.q.source,
    mood: s.mood,
    isFavorite: s.fav,
    generatedAt: new Date(now - s.hoursAgo * 3600_000).toISOString(),
  }));

  writeGuestJson(GUEST_HISTORY_KEY, initial);
  const initialFavs: FavoriteEntry[] = initial
    .filter((h) => h.isFavorite)
    .map((h) => ({
      id: h.quoteId,
      userId: 'guest',
      quoteId: h.quoteId,
      quoteText: h.quoteText,
      author: h.author,
      category: h.category,
      source: h.source,
      collectionId: idxCollectionForCategory(h.category),
      createdAt: h.generatedAt,
    }));
  writeGuestJson(GUEST_FAVORITES_KEY, initialFavs);

  const initialCollections: QuoteCollection[] = [
    {
      id: 'col_deep_work',
      userId: 'guest',
      name: 'Deep Work & Craft',
      description: 'Quotes on clarity, engineering, and calm focus.',
      color: '#4338CA',
      createdAt: new Date(now - 96 * 3600_000).toISOString(),
      updatedAt: new Date(now - 96 * 3600_000).toISOString(),
    },
    {
      id: 'col_stoic',
      userId: 'guest',
      name: 'Stoic Anchors',
      description: 'Daily reminders for resilience under pressure.',
      color: '#F59E0B',
      createdAt: new Date(now - 96 * 3600_000).toISOString(),
      updatedAt: new Date(now - 96 * 3600_000).toISOString(),
    },
  ];
  writeGuestJson(GUEST_COLLECTIONS_KEY, initialCollections);

  return initial;
}

function idxCollectionForCategory(category: string): string {
  if (category === 'Technology' || category === 'Creativity') return 'col_deep_work';
  if (category === 'Philosophy') return 'col_stoic';
  return '';
}

export function loadGuestState(): {
  history: HistoryEntry[];
  favorites: FavoriteEntry[];
  collections: QuoteCollection[];
  notes: QuoteNote[];
  activity: ActivityEntry[];
} {
  const history = getSeededGuestHistory();
  const favorites = readGuestJson<FavoriteEntry[]>(GUEST_FAVORITES_KEY, []);
  const collections = readGuestJson<QuoteCollection[]>(GUEST_COLLECTIONS_KEY, []);
  const notes = readGuestJson<QuoteNote[]>(GUEST_NOTES_KEY, []);
  const activity = readGuestJson<ActivityEntry[]>(GUEST_ACTIVITY_KEY, []);
  return { history, favorites, collections, notes, activity };
}

export function saveGuestState(partial: {
  history?: HistoryEntry[];
  favorites?: FavoriteEntry[];
  collections?: QuoteCollection[];
  notes?: QuoteNote[];
  activity?: ActivityEntry[];
}) {
  if (partial.history) writeGuestJson(GUEST_HISTORY_KEY, partial.history);
  if (partial.favorites) writeGuestJson(GUEST_FAVORITES_KEY, partial.favorites);
  if (partial.collections) writeGuestJson(GUEST_COLLECTIONS_KEY, partial.collections);
  if (partial.notes) writeGuestJson(GUEST_NOTES_KEY, partial.notes);
  if (partial.activity) writeGuestJson(GUEST_ACTIVITY_KEY, partial.activity);
}

export function loadGuestPreferences(): Pick<
  UserProfile,
  'theme' | 'dailyInspirationEnabled' | 'preferredCategory' | 'preferredApiProvider'
> {
  return readGuestJson(GUEST_SETTINGS_KEY, {
    theme: 'light',
    dailyInspirationEnabled: false,
    preferredCategory: 'All',
    preferredApiProvider: 'auto',
  });
}

export function saveGuestPreferences(
  prefs: Pick<
    UserProfile,
    'theme' | 'dailyInspirationEnabled' | 'preferredCategory' | 'preferredApiProvider'
  >
) {
  writeGuestJson(GUEST_SETTINGS_KEY, prefs);
}

// Firestore Authenticated Persistence
export async function ensureUserProfile(user: User): Promise<UserProfile> {
  const userPath = `users/${user.uid}`;
  const ref = doc(db, 'users', user.uid);
  try {
    const snap = await getDoc(ref);
    if (snap.exists()) {
      const data = snap.data();
      return {
        uid: data.uid,
        displayName: data.displayName,
        email: data.email,
        photoURL: data.photoURL || '',
        theme: data.theme === 'dark' ? 'dark' : 'light',
        dailyInspirationEnabled: Boolean(data.dailyInspirationEnabled),
        preferredCategory: data.preferredCategory || 'All',
        preferredApiProvider: data.preferredApiProvider || 'auto',
        createdAt: toIsoString(data.createdAt),
        updatedAt: toIsoString(data.updatedAt),
      };
    }

    const guestPrefs = loadGuestPreferences();
    const newProfile = {
      uid: user.uid,
      displayName: truncateForBlueprint(user.displayName || 'QuoteVerse Reader', 120),
      email: truncateForBlueprint(user.email || 'user@quoteverse.app', 200),
      photoURL: truncateForBlueprint(user.photoURL || '', 500),
      theme: guestPrefs.theme,
      dailyInspirationEnabled: guestPrefs.dailyInspirationEnabled,
      preferredCategory: truncateForBlueprint(guestPrefs.preferredCategory, 60),
      preferredApiProvider: truncateForBlueprint(guestPrefs.preferredApiProvider, 40),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    await setDoc(ref, newProfile);
    return {
      ...newProfile,
      preferredApiProvider: guestPrefs.preferredApiProvider,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }
}

export async function updateUserPreferences(
  uid: string,
  updates: Partial<
    Pick<
      UserProfile,
      'displayName' | 'theme' | 'dailyInspirationEnabled' | 'preferredCategory' | 'preferredApiProvider'
    >
  >
): Promise<void> {
  const userPath = `users/${uid}`;
  try {
    const payload: Record<string, unknown> = {
      updatedAt: serverTimestamp(),
    };
    if (updates.displayName !== undefined) {
      payload.displayName = truncateForBlueprint(updates.displayName || 'Reader', 120);
    }
    if (updates.theme !== undefined) {
      payload.theme = updates.theme === 'dark' ? 'dark' : 'light';
    }
    if (updates.dailyInspirationEnabled !== undefined) {
      payload.dailyInspirationEnabled = Boolean(updates.dailyInspirationEnabled);
    }
    if (updates.preferredCategory !== undefined) {
      payload.preferredCategory = truncateForBlueprint(updates.preferredCategory, 60);
    }
    if (updates.preferredApiProvider !== undefined) {
      payload.preferredApiProvider = truncateForBlueprint(updates.preferredApiProvider, 40);
    }
    await updateDoc(doc(db, 'users', uid), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, userPath);
  }
}

export async function saveGeneratedQuoteToFirestore(
  uid: string,
  quote: Quote,
  mood: string
): Promise<HistoryEntry> {
  const canonicalId = sanitizeId(buildCanonicalQuoteId(quote.quoteText, quote.author));
  const quotePath = `quotes/${canonicalId}`;
  const historyId = sanitizeId(`h_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
  const historyPath = `users/${uid}/history/${historyId}`;

  try {
    const quoteRef = doc(db, 'quotes', canonicalId);
    const quoteSnap = await getDoc(quoteRef);
    if (!quoteSnap.exists()) {
      await setDoc(quoteRef, {
        quoteText: truncateForBlueprint(quote.quoteText, 1000),
        author: truncateForBlueprint(quote.author, 160),
        category: truncateForBlueprint(quote.category, 60),
        source: truncateForBlueprint(quote.source, 100),
        externalApiId: truncateForBlueprint(quote.externalApiId || canonicalId, 160),
        createdBy: uid,
        createdAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, quotePath);
  }

  try {
    await setDoc(doc(db, 'users', uid, 'history', historyId), {
      userId: uid,
      quoteId: canonicalId,
      quoteText: truncateForBlueprint(quote.quoteText, 1000),
      author: truncateForBlueprint(quote.author, 160),
      category: truncateForBlueprint(quote.category, 60),
      source: truncateForBlueprint(quote.source, 100),
      mood: truncateForBlueprint(mood || 'General', 40),
      isFavorite: false,
      generatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, historyPath);
  }

  await logUserActivity(uid, 'generate', quote.category, mood, `Generated quote by ${quote.author}`);

  return {
    id: historyId,
    userId: uid,
    quoteId: canonicalId,
    quoteText: quote.quoteText,
    author: quote.author,
    category: quote.category,
    source: quote.source,
    mood: mood || 'General',
    isFavorite: false,
    generatedAt: new Date().toISOString(),
  };
}

export async function deleteHistoryFromFirestore(uid: string, historyId: string): Promise<void> {
  const path = `users/${uid}/history/${historyId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'history', historyId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function addFavoriteToFirestore(
  uid: string,
  quote: { quoteId: string; quoteText: string; author: string; category: string; source: string },
  collectionId = '',
  matchingHistoryIds: string[] = []
): Promise<FavoriteEntry> {
  const favId = sanitizeId(quote.quoteId);
  const path = `users/${uid}/favorites/${favId}`;
  try {
    await setDoc(doc(db, 'users', uid, 'favorites', favId), {
      userId: uid,
      quoteId: favId,
      quoteText: truncateForBlueprint(quote.quoteText, 1000),
      author: truncateForBlueprint(quote.author, 160),
      category: truncateForBlueprint(quote.category, 60),
      source: truncateForBlueprint(quote.source, 100),
      collectionId: truncateForBlueprint(collectionId, 128),
      createdAt: serverTimestamp(),
    });
    for (const hId of matchingHistoryIds) {
      await updateDoc(doc(db, 'users', uid, 'history', hId), { isFavorite: true });
    }
    await logUserActivity(uid, 'favorite', quote.category, '', `Favorited quote by ${quote.author}`);
    return {
      id: favId,
      userId: uid,
      quoteId: favId,
      quoteText: quote.quoteText,
      author: quote.author,
      category: quote.category,
      source: quote.source,
      collectionId,
      createdAt: new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function removeFavoriteFromFirestore(
  uid: string,
  quoteId: string,
  matchingHistoryIds: string[] = []
): Promise<void> {
  const favId = sanitizeId(quoteId);
  const path = `users/${uid}/favorites/${favId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'favorites', favId));
    for (const hId of matchingHistoryIds) {
      await updateDoc(doc(db, 'users', uid, 'history', hId), { isFavorite: false });
    }
    await logUserActivity(uid, 'unfavorite', '', '', 'Removed quote from favorites');
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function assignFavoriteCollectionFirestore(
  uid: string,
  favoriteId: string,
  collectionId: string
): Promise<void> {
  const path = `users/${uid}/favorites/${favoriteId}`;
  try {
    await updateDoc(doc(db, 'users', uid, 'favorites', favoriteId), {
      collectionId: truncateForBlueprint(collectionId, 128),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function createCollectionFirestore(
  uid: string,
  name: string,
  description: string,
  color: string
): Promise<QuoteCollection> {
  const colId = sanitizeId(`col_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`);
  const path = `users/${uid}/collections/${colId}`;
  try {
    await setDoc(doc(db, 'users', uid, 'collections', colId), {
      userId: uid,
      name: truncateForBlueprint(name, 80),
      description: truncateForBlueprint(description, 300),
      color: truncateForBlueprint(color || '#4338CA', 20),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return {
      id: colId,
      userId: uid,
      name,
      description,
      color,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteCollectionFirestore(uid: string, collectionId: string): Promise<void> {
  const path = `users/${uid}/collections/${collectionId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'collections', collectionId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function saveNoteFirestore(
  uid: string,
  note: { quoteId: string; title: string; body: string; quoteText: string; author: string }
): Promise<QuoteNote> {
  const noteId = sanitizeId(`note_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`);
  const path = `users/${uid}/notes/${noteId}`;
  try {
    await setDoc(doc(db, 'users', uid, 'notes', noteId), {
      userId: uid,
      quoteId: sanitizeId(note.quoteId),
      title: truncateForBlueprint(note.title, 120),
      body: truncateForBlueprint(note.body, 2000),
      quoteText: truncateForBlueprint(note.quoteText, 1000),
      author: truncateForBlueprint(note.author, 160),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    await logUserActivity(uid, 'note_save', '', '', `Saved note: ${note.title}`);
    return {
      id: noteId,
      userId: uid,
      quoteId: sanitizeId(note.quoteId),
      title: note.title,
      body: note.body,
      quoteText: note.quoteText,
      author: note.author,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteNoteFirestore(uid: string, noteId: string): Promise<void> {
  const path = `users/${uid}/notes/${noteId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'notes', noteId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function logUserActivity(
  uid: string,
  activityType: ActivityType,
  category: string,
  mood: string,
  details: string
): Promise<void> {
  const actId = sanitizeId(`act_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`);
  const path = `users/${uid}/activity/${actId}`;
  try {
    await setDoc(doc(db, 'users', uid, 'activity', actId), {
      userId: uid,
      activityType,
      category: truncateForBlueprint(category, 60),
      mood: truncateForBlueprint(mood, 40),
      details: truncateForBlueprint(details, 300),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export function subscribeUserCollections(
  uid: string,
  callbacks: {
    onHistory: (items: HistoryEntry[]) => void;
    onFavorites: (items: FavoriteEntry[]) => void;
    onCollections: (items: QuoteCollection[]) => void;
    onNotes: (items: QuoteNote[]) => void;
    onActivity: (items: ActivityEntry[]) => void;
    onError: (err: Error) => void;
  }
): () => void {
  const unsubs: Unsubscribe[] = [];

  const histPath = `users/${uid}/history`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'users', uid, 'history'), orderBy('generatedAt', 'desc')),
      (snap) => {
        const items: HistoryEntry[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            userId: data.userId,
            quoteId: data.quoteId,
            quoteText: data.quoteText,
            author: data.author,
            category: data.category,
            source: data.source,
            mood: data.mood || 'General',
            isFavorite: Boolean(data.isFavorite),
            generatedAt: toIsoString(data.generatedAt),
          };
        });
        callbacks.onHistory(items);
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, histPath);
        } catch (wrapped) {
          callbacks.onError(wrapped as Error);
        }
      }
    )
  );

  const favPath = `users/${uid}/favorites`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'users', uid, 'favorites'), orderBy('createdAt', 'desc')),
      (snap) => {
        const items: FavoriteEntry[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            userId: data.userId,
            quoteId: data.quoteId,
            quoteText: data.quoteText,
            author: data.author,
            category: data.category,
            source: data.source,
            collectionId: data.collectionId || '',
            createdAt: toIsoString(data.createdAt),
          };
        });
        callbacks.onFavorites(items);
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, favPath);
        } catch (wrapped) {
          callbacks.onError(wrapped as Error);
        }
      }
    )
  );

  const colPath = `users/${uid}/collections`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'users', uid, 'collections'), orderBy('createdAt', 'desc')),
      (snap) => {
        const items: QuoteCollection[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            userId: data.userId,
            name: data.name,
            description: data.description || '',
            color: data.color || '#4338CA',
            createdAt: toIsoString(data.createdAt),
            updatedAt: toIsoString(data.updatedAt),
          };
        });
        callbacks.onCollections(items);
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, colPath);
        } catch (wrapped) {
          callbacks.onError(wrapped as Error);
        }
      }
    )
  );

  const notePath = `users/${uid}/notes`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'users', uid, 'notes'), orderBy('createdAt', 'desc')),
      (snap) => {
        const items: QuoteNote[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            userId: data.userId,
            quoteId: data.quoteId,
            title: data.title,
            body: data.body,
            quoteText: data.quoteText || '',
            author: data.author || '',
            createdAt: toIsoString(data.createdAt),
            updatedAt: toIsoString(data.updatedAt),
          };
        });
        callbacks.onNotes(items);
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, notePath);
        } catch (wrapped) {
          callbacks.onError(wrapped as Error);
        }
      }
    )
  );

  const actPath = `users/${uid}/activity`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'users', uid, 'activity'), orderBy('createdAt', 'desc')),
      (snap) => {
        const items: ActivityEntry[] = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: d.id,
            userId: data.userId,
            activityType: data.activityType,
            category: data.category || '',
            mood: data.mood || '',
            details: data.details || '',
            createdAt: toIsoString(data.createdAt),
          };
        });
        callbacks.onActivity(items);
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, actPath);
        } catch (wrapped) {
          callbacks.onError(wrapped as Error);
        }
      }
    )
  );

  return () => {
    unsubs.forEach((u) => u());
  };
}

export async function migrateGuestHistoryToFirestore(uid: string): Promise<number> {
  const guest = loadGuestState();
  const existingSnap = await getDocs(collection(db, 'users', uid, 'history'));
  if (!existingSnap.empty) return 0;

  let migrated = 0;
  for (const h of guest.history.slice(0, 10)) {
    await saveGeneratedQuoteToFirestore(
      uid,
      {
        id: h.quoteId,
        quoteText: h.quoteText,
        author: h.author,
        category: h.category,
        source: h.source,
        externalApiId: h.quoteId,
        createdAt: h.generatedAt,
      },
      h.mood
    );
    if (h.isFavorite) {
      await addFavoriteToFirestore(uid, {
        quoteId: h.quoteId,
        quoteText: h.quoteText,
        author: h.author,
        category: h.category,
        source: h.source,
      });
    }
    migrated++;
  }
  return migrated;
}
