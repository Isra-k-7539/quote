import type { CategoryInfo, MoodOption, Quote } from '../types/quoteverse.ts';

export const ALL_CATEGORIES: string[] = [
  'Motivation',
  'Success',
  'Life',
  'Love',
  'Friendship',
  'Happiness',
  'Philosophy',
  'Wisdom',
  'Leadership',
  'Technology',
  'Education',
  'Creativity',
  'Confidence',
  'Personal Growth',
];

export const ALL_MOODS: { mood: MoodOption; description: string; categories: string[] }[] = [
  { mood: 'Motivated', description: 'Fuel momentum and decisive action', categories: ['Motivation', 'Success', 'Leadership'] },
  { mood: 'Happy', description: 'Celebrate joy, gratitude, and presence', categories: ['Happiness', 'Love', 'Friendship'] },
  { mood: 'Confident', description: 'Build steady self-belief and courage', categories: ['Confidence', 'Success', 'Leadership'] },
  { mood: 'Focused', description: 'Sharpen clarity and deep craft', categories: ['Technology', 'Education', 'Creativity'] },
  { mood: 'Hopeful', description: 'Find renewal and quiet optimism', categories: ['Life', 'Personal Growth', 'Happiness'] },
  { mood: 'Stressed', description: 'Restore calm and perspective', categories: ['Philosophy', 'Wisdom', 'Life'] },
  { mood: 'Sad', description: 'Gentle comfort and resilience', categories: ['Life', 'Philosophy', 'Friendship'] },
];

export const CATEGORY_DESCRIPTIONS: Record<string, string> = {
  Motivation: 'Sparks of resolve to begin, endure, and overcome inertia.',
  Success: 'Lessons on mastery, patience, and meaningful achievement.',
  Life: 'Reflections on time, presence, and the art of living well.',
  Love: 'Observations on devotion, tenderness, and human connection.',
  Friendship: 'Tributes to loyalty, shared laughter, and trusted company.',
  Happiness: 'Insights into contentment, gratitude, and quiet joy.',
  Philosophy: 'Enduring questions from Stoic, classical, and modern thinkers.',
  Wisdom: 'Distilled judgment shaped by experience and reflection.',
  Leadership: 'Principles of stewardship, courage, and inspiring others.',
  Technology: 'Perspectives on craft, tools, invention, and human progress.',
  Education: 'Thoughts on curiosity, lifelong study, and mental freedom.',
  Creativity: 'Notes on imagination, original expression, and making.',
  Confidence: 'Anchors for self-trust, poise, and bold conviction.',
  'Personal Growth': 'Milestones in discipline, self-awareness, and transformation.',
};

interface SeedQuoteInput {
  quoteText: string;
  author: string;
  category: string;
  externalApiId: string;
}

const RAW_SEED_QUOTES: SeedQuoteInput[] = [
  { quoteText: 'We are what we repeatedly do. Excellence, then, is not an act, but a habit.', author: 'Will Durant', category: 'Motivation', externalApiId: 'seed-mot-1' },
  { quoteText: 'Start where you are. Use what you have. Do what you can.', author: 'Arthur Ashe', category: 'Motivation', externalApiId: 'seed-mot-2' },
  { quoteText: 'Action is the foundational key to all success.', author: 'Pablo Picasso', category: 'Motivation', externalApiId: 'seed-mot-3' },
  { quoteText: 'Do not wait to strike till the iron is hot; but make it hot by striking.', author: 'William Butler Yeats', category: 'Motivation', externalApiId: 'seed-mot-4' },

  { quoteText: 'Success is not final, failure is not fatal: it is the courage to continue that counts.', author: 'Winston Churchill', category: 'Success', externalApiId: 'seed-suc-1' },
  { quoteText: 'The secret of getting ahead is getting started.', author: 'Mark Twain', category: 'Success', externalApiId: 'seed-suc-2' },
  { quoteText: 'Patience, persistence and perspiration make an unbeatable combination for success.', author: 'Napoleon Hill', category: 'Success', externalApiId: 'seed-suc-3' },
  { quoteText: 'Success usually comes to those who are too busy to be looking for it.', author: 'Henry David Thoreau', category: 'Success', externalApiId: 'seed-suc-4' },

  { quoteText: 'In the middle of difficulty lies opportunity.', author: 'Albert Einstein', category: 'Life', externalApiId: 'seed-lif-1' },
  { quoteText: 'Life is really simple, but we insist on making it complicated.', author: 'Confucius', category: 'Life', externalApiId: 'seed-lif-2' },
  { quoteText: 'How we spend our days is, of course, how we spend our lives.', author: 'Annie Dillard', category: 'Life', externalApiId: 'seed-lif-3' },
  { quoteText: 'Turn your wounds into wisdom.', author: 'Oprah Winfrey', category: 'Life', externalApiId: 'seed-lif-4' },

  { quoteText: 'Where there is love there is life.', author: 'Mahatma Gandhi', category: 'Love', externalApiId: 'seed-lov-1' },
  { quoteText: 'To love and be loved is to feel the sun from both sides.', author: 'David Viscott', category: 'Love', externalApiId: 'seed-lov-2' },
  { quoteText: 'Love recognizes no barriers. It jumps hurdles, leaps fences, penetrates walls to arrive at its destination full of hope.', author: 'Maya Angelou', category: 'Love', externalApiId: 'seed-lov-3' },
  { quoteText: 'The best thing to hold onto in life is each other.', author: 'Audrey Hepburn', category: 'Love', externalApiId: 'seed-lov-4' },

  { quoteText: 'A friend is someone who knows all about you and still loves you.', author: 'Elbert Hubbard', category: 'Friendship', externalApiId: 'seed-fri-1' },
  { quoteText: 'Friendship is born at that moment when one person says to another: What! You too? I thought I was the only one.', author: 'C.S. Lewis', category: 'Friendship', externalApiId: 'seed-fri-2' },
  { quoteText: 'Walking with a friend in the dark is better than walking alone in the light.', author: 'Helen Keller', category: 'Friendship', externalApiId: 'seed-fri-3' },
  { quoteText: 'Truly great friends are hard to find, difficult to leave, and impossible to forget.', author: 'G. Randolf', category: 'Friendship', externalApiId: 'seed-fri-4' },

  { quoteText: 'Happiness is not something ready made. It comes from your own actions.', author: 'Dalai Lama', category: 'Happiness', externalApiId: 'seed-hap-1' },
  { quoteText: 'Very little is needed to make a happy life; it is all within yourself, in your way of thinking.', author: 'Marcus Aurelius', category: 'Happiness', externalApiId: 'seed-hap-2' },
  { quoteText: 'For every minute you are angry you lose sixty seconds of happiness.', author: 'Ralph Waldo Emerson', category: 'Happiness', externalApiId: 'seed-hap-3' },
  { quoteText: 'Joy is not in things; it is in us.', author: 'Richard Wagner', category: 'Happiness', externalApiId: 'seed-hap-4' },

  { quoteText: 'The impediment to action advances action. What stands in the way becomes the way.', author: 'Marcus Aurelius', category: 'Philosophy', externalApiId: 'seed-phi-1' },
  { quoteText: 'He who has a why to live can bear almost any how.', author: 'Friedrich Nietzsche', category: 'Philosophy', externalApiId: 'seed-phi-2' },
  { quoteText: 'We suffer more often in imagination than in reality.', author: 'Seneca', category: 'Philosophy', externalApiId: 'seed-phi-3' },
  { quoteText: 'The unexamined life is not worth living.', author: 'Socrates', category: 'Philosophy', externalApiId: 'seed-phi-4' },

  { quoteText: 'Knowing others is intelligence; knowing yourself is true wisdom.', author: 'Lao Tzu', category: 'Wisdom', externalApiId: 'seed-wis-1' },
  { quoteText: 'The only true wisdom is in knowing you know nothing.', author: 'Socrates', category: 'Wisdom', externalApiId: 'seed-wis-2' },
  { quoteText: 'Silence is a source of great strength.', author: 'Lao Tzu', category: 'Wisdom', externalApiId: 'seed-wis-3' },
  { quoteText: 'Wisdom begins in wonder.', author: 'Socrates', category: 'Wisdom', externalApiId: 'seed-wis-4' },

  { quoteText: 'A leader is one who knows the way, goes the way, and shows the way.', author: 'John C. Maxwell', category: 'Leadership', externalApiId: 'seed-lea-1' },
  { quoteText: 'Before you are a leader, success is all about growing yourself. When you become a leader, success is all about growing others.', author: 'Jack Welch', category: 'Leadership', externalApiId: 'seed-lea-2' },
  { quoteText: 'The function of leadership is to produce more leaders, not more followers.', author: 'Ralph Nader', category: 'Leadership', externalApiId: 'seed-lea-3' },
  { quoteText: 'Innovation distinguishes between a leader and a follower.', author: 'Steve Jobs', category: 'Leadership', externalApiId: 'seed-lea-4' },

  { quoteText: 'Simplicity is prerequisite for reliability.', author: 'Edsger W. Dijkstra', category: 'Technology', externalApiId: 'seed-tec-1' },
  { quoteText: 'Any sufficiently advanced technology is indistinguishable from magic.', author: 'Arthur C. Clarke', category: 'Technology', externalApiId: 'seed-tec-2' },
  { quoteText: 'Technology is best when it brings people together.', author: 'Matt Mullenweg', category: 'Technology', externalApiId: 'seed-tec-3' },
  { quoteText: 'First, solve the problem. Then, write the code.', author: 'John Johnson', category: 'Technology', externalApiId: 'seed-tec-4' },

  { quoteText: 'Education is the kindling of a flame, not the filling of a vessel.', author: 'Socrates', category: 'Education', externalApiId: 'seed-edu-1' },
  { quoteText: 'Live as if you were to die tomorrow. Learn as if you were to live forever.', author: 'Mahatma Gandhi', category: 'Education', externalApiId: 'seed-edu-2' },
  { quoteText: 'The beautiful thing about learning is that nobody can take it away from you.', author: 'B.B. King', category: 'Education', externalApiId: 'seed-edu-3' },
  { quoteText: 'An investment in knowledge pays the best interest.', author: 'Benjamin Franklin', category: 'Education', externalApiId: 'seed-edu-4' },

  { quoteText: 'Creativity takes courage.', author: 'Henri Matisse', category: 'Creativity', externalApiId: 'seed-cre-1' },
  { quoteText: 'You cannot use up creativity. The more you use, the more you have.', author: 'Maya Angelou', category: 'Creativity', externalApiId: 'seed-cre-2' },
  { quoteText: 'Logic will get you from A to B. Imagination will take you everywhere.', author: 'Albert Einstein', category: 'Creativity', externalApiId: 'seed-cre-3' },
  { quoteText: 'Every artist was first an amateur.', author: 'Ralph Waldo Emerson', category: 'Creativity', externalApiId: 'seed-cre-4' },

  { quoteText: 'Believe you can and you are halfway there.', author: 'Theodore Roosevelt', category: 'Confidence', externalApiId: 'seed-con-1' },
  { quoteText: 'With confidence, you have won before you have started.', author: 'Marcus Garvey', category: 'Confidence', externalApiId: 'seed-con-2' },
  { quoteText: 'No one can make you feel inferior without your consent.', author: 'Eleanor Roosevelt', category: 'Confidence', externalApiId: 'seed-con-3' },
  { quoteText: 'Self-trust is the first secret of success.', author: 'Ralph Waldo Emerson', category: 'Confidence', externalApiId: 'seed-con-4' },

  { quoteText: 'The only person you are destined to become is the person you decide to be.', author: 'Ralph Waldo Emerson', category: 'Personal Growth', externalApiId: 'seed-pg-1' },
  { quoteText: 'What you get by achieving your goals is not as important as what you become by achieving your goals.', author: 'Zig Ziglar', category: 'Personal Growth', externalApiId: 'seed-pg-2' },
  { quoteText: 'Small daily improvements over time lead to stunning results.', author: 'Robin Sharma', category: 'Personal Growth', externalApiId: 'seed-pg-3' },
  { quoteText: 'Growth begins at the end of your comfort zone.', author: 'Neale Donald Walsch', category: 'Personal Growth', externalApiId: 'seed-pg-4' },
];

export const CURATED_QUOTES: Quote[] = RAW_SEED_QUOTES.map((q) => ({
  id: q.externalApiId,
  quoteText: q.quoteText,
  author: q.author,
  category: q.category,
  source: 'QuoteVerse Archive',
  externalApiId: q.externalApiId,
  createdAt: '2026-01-01T00:00:00.000Z',
}));

export function getCategoryCatalog(): CategoryInfo[] {
  return ALL_CATEGORIES.map((name) => {
    const matches = CURATED_QUOTES.filter((q) => q.category === name);
    const first = matches[0] ?? CURATED_QUOTES[0];
    return {
      id: name.toLowerCase().replace(/\s+/g, '-'),
      name,
      description: CATEGORY_DESCRIPTIONS[name] ?? '',
      quoteCount: matches.length,
      featuredQuote: {
        quoteText: first.quoteText,
        author: first.author,
      },
    };
  });
}
