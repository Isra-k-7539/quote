import express, { Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import { ALL_CATEGORIES, CURATED_QUOTES, getCategoryCatalog } from './src/data/quotesCatalog.ts';
import { buildCanonicalQuoteId, truncateForBlueprint } from './src/utils/quoteLogic.ts';
import type { ApiProviderOption, GroundingSource, Quote } from './src/types/quoteverse.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;

interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

const memoryCache = new Map<string, CacheEntry<unknown>>();

function getCached<T>(key: string): T | null {
  const entry = memoryCache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    memoryCache.delete(key);
    return null;
  }
  return entry.value as T;
}

function setCached<T>(key: string, value: T, ttlMs: number): void {
  memoryCache.set(key, { value, expiresAt: Date.now() + ttlMs });
}

// Simple sliding-window rate limiter for /api routes
const rateHits = new Map<string, number[]>();
function rateLimiter(req: Request, res: Response, next: NextFunction) {
  const ip = req.ip || 'local';
  const now = Date.now();
  const windowMs = 60_000;
  const maxRequests = 120;
  const timestamps = (rateHits.get(ip) ?? []).filter((t) => now - t < windowMs);
  if (timestamps.length >= maxRequests) {
    res.status(429).json({ error: 'Too many requests. Please slow down and try again shortly.' });
    return;
  }
  timestamps.push(now);
  rateHits.set(ip, timestamps);
  next();
}

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function mapToCanonicalCategory(rawTag: string | undefined, text: string, fallbackCategory?: string): string {
  if (fallbackCategory && ALL_CATEGORIES.includes(fallbackCategory)) {
    return fallbackCategory;
  }
  const combined = `${rawTag ?? ''} ${text}`.toLowerCase();
  const keywordMap: [string, string[]][] = [
    ['Technology', ['technology', 'code', 'software', 'machine', 'science', 'computer', 'digital', 'invent']],
    ['Creativity', ['creativ', 'art', 'imagination', 'paint', 'music', 'design', 'write']],
    ['Leadership', ['leader', 'lead', 'team', 'vision', 'influence']],
    ['Philosophy', ['stoic', 'philosoph', 'virtue', 'reason', 'mind', 'suffering', 'reality']],
    ['Wisdom', ['wisdom', 'wise', 'knowledge', 'truth', 'silence', 'understand']],
    ['Education', ['learn', 'education', 'study', 'book', 'school', 'teacher', 'curiosity']],
    ['Success', ['success', 'achieve', 'win', 'goal', 'persist', 'fail']],
    ['Confidence', ['confiden', 'brave', 'courage', 'fear', 'self-trust', 'believe']],
    ['Personal Growth', ['growth', 'habit', 'change', 'improve', 'become', 'discipline']],
    ['Happiness', ['happy', 'happiness', 'joy', 'smile', 'gratitude', 'peace']],
    ['Love', ['love', 'heart', 'compassion', 'kindness', 'affection']],
    ['Friendship', ['friend', 'companion', 'together', 'trust', 'loyalty']],
    ['Motivation', ['motiv', 'action', 'start', 'do not wait', 'drive', 'effort']],
    ['Life', ['life', 'live', 'days', 'time', 'journey', 'human']],
  ];
  for (const [cat, keywords] of keywordMap) {
    if (keywords.some((k) => combined.includes(k))) {
      return cat;
    }
  }
  return 'Wisdom';
}

async function fetchJsonWithTimeout(url: string, timeoutMs = 3500): Promise<unknown> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) {
      throw new Error(`HTTP ${res.status} from ${url}`);
    }
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

async function fetchFromZenQuotes(requestedCategory?: string): Promise<Quote[]> {
  const cacheKey = 'ext:zenquotes:pool';
  let pool = getCached<Quote[]>(cacheKey);
  if (!pool) {
    const data = (await fetchJsonWithTimeout('https://zenquotes.io/api/quotes')) as Array<{
      q?: string;
      a?: string;
    }>;
    if (Array.isArray(data) && data.length > 0) {
      pool = data
        .filter((item) => item.q && item.a && item.a !== 'zenquotes.io')
        .map((item) => {
          const text = truncateForBlueprint(item.q || '', 1000);
          const author = truncateForBlueprint(item.a || 'Unknown', 160);
          const id = buildCanonicalQuoteId(text, author);
          return {
            id,
            quoteText: text,
            author,
            category: mapToCanonicalCategory('', text),
            source: 'ZenQuotes API',
            externalApiId: `zq-${id}`,
            createdAt: new Date().toISOString(),
          };
        });
      setCached(cacheKey, pool, 5 * 60_000);
    }
  }
  if (!pool || pool.length === 0) return [];
  if (requestedCategory && requestedCategory !== 'All') {
    const matching = pool.filter((q) => q.category === requestedCategory);
    return matching.length > 0 ? matching : [];
  }
  return pool;
}

async function fetchFromDummyJson(requestedCategory?: string): Promise<Quote[]> {
  const cacheKey = 'ext:dummyjson:pool';
  let pool = getCached<Quote[]>(cacheKey);
  if (!pool) {
    const data = (await fetchJsonWithTimeout('https://dummyjson.com/quotes?limit=30')) as {
      quotes?: Array<{ id?: number; quote?: string; author?: string }>;
    };
    const items = data?.quotes;
    if (Array.isArray(items) && items.length > 0) {
      pool = items
        .filter((item) => item.quote && item.author)
        .map((item) => {
          const text = truncateForBlueprint(item.quote || '', 1000);
          const author = truncateForBlueprint(item.author || 'Unknown', 160);
          const id = buildCanonicalQuoteId(text, author);
          return {
            id,
            quoteText: text,
            author,
            category: mapToCanonicalCategory('', text),
            source: 'DummyJSON Quotes API',
            externalApiId: `dj-${item.id ?? id}`,
            createdAt: new Date().toISOString(),
          };
        });
      setCached(cacheKey, pool, 10 * 60_000);
    }
  }
  if (!pool || pool.length === 0) return [];
  if (requestedCategory && requestedCategory !== 'All') {
    const matching = pool.filter((q) => q.category === requestedCategory);
    return matching.length > 0 ? matching : [];
  }
  return pool;
}

async function fetchFromQuotable(requestedCategory?: string): Promise<Quote[]> {
  const tagMap: Record<string, string> = {
    Motivation: 'motivational',
    Success: 'success',
    Life: 'life',
    Love: 'love',
    Friendship: 'friendship',
    Happiness: 'happiness',
    Philosophy: 'philosophy',
    Wisdom: 'wisdom',
    Leadership: 'leadership',
    Technology: 'technology',
    Education: 'education',
    Creativity: 'creativity',
    Confidence: 'courage',
    'Personal Growth': 'character',
  };
  const tag = requestedCategory && tagMap[requestedCategory] ? `?tags=${tagMap[requestedCategory]}` : '';
  const data = (await fetchJsonWithTimeout(`https://api.quotable.io/quotes/random${tag}`, 3000)) as Array<{
    _id?: string;
    content?: string;
    author?: string;
    tags?: string[];
  }>;
  if (!Array.isArray(data) || data.length === 0) return [];
  return data
    .filter((item) => item.content && item.author)
    .map((item) => {
      const text = truncateForBlueprint(item.content || '', 1000);
      const author = truncateForBlueprint(item.author || 'Unknown', 160);
      const id = buildCanonicalQuoteId(text, author);
      return {
        id,
        quoteText: text,
        author,
        category: mapToCanonicalCategory(item.tags?.[0], text, requestedCategory !== 'All' ? requestedCategory : undefined),
        source: 'Quotable API',
        externalApiId: `qt-${item._id ?? id}`,
        createdAt: new Date().toISOString(),
      };
    });
}

function pickNonDuplicate(candidates: Quote[], excludeIds: Set<string>): Quote | null {
  if (candidates.length === 0) return null;
  const fresh = candidates.filter((q) => !excludeIds.has(q.id));
  const pool = fresh.length > 0 ? fresh : candidates;
  return pool[Math.floor(Math.random() * pool.length)];
}

async function resolveQuote(
  provider: ApiProviderOption,
  category: string | undefined,
  excludeIds: Set<string>
): Promise<{ quote: Quote; fallbackUsed: boolean; providerError?: string }> {
  const cleanCategory = category && category !== 'All' ? category : undefined;
  const order: ApiProviderOption[] =
    provider === 'auto'
      ? ['dummyjson', 'zenquotes', 'quotable', 'curated']
      : [provider, 'curated'];

  let lastError: string | undefined;

  for (const current of order) {
    if (current === 'curated') {
      const pool = cleanCategory
        ? CURATED_QUOTES.filter((q) => q.category === cleanCategory)
        : CURATED_QUOTES;
      const picked = pickNonDuplicate(pool.length > 0 ? pool : CURATED_QUOTES, excludeIds);
      if (picked) {
        return {
          quote: {
            ...picked,
            id: buildCanonicalQuoteId(picked.quoteText, picked.author),
            createdAt: new Date().toISOString(),
          },
          fallbackUsed: provider !== 'curated' && Boolean(lastError),
          providerError: lastError,
        };
      }
      continue;
    }

    try {
      let results: Quote[] = [];
      if (current === 'zenquotes') {
        results = await fetchFromZenQuotes(cleanCategory);
      } else if (current === 'dummyjson') {
        results = await fetchFromDummyJson(cleanCategory);
      } else if (current === 'quotable') {
        results = await fetchFromQuotable(cleanCategory);
      }
      const picked = pickNonDuplicate(results, excludeIds);
      if (picked) {
        return { quote: picked, fallbackUsed: false };
      }
    } catch (err) {
      lastError = err instanceof Error ? err.message : 'External quote provider unreachable';
    }
  }

  const fallback = CURATED_QUOTES[0];
  return {
    quote: {
      ...fallback,
      id: buildCanonicalQuoteId(fallback.quoteText, fallback.author),
      createdAt: new Date().toISOString(),
    },
    fallbackUsed: true,
    providerError: lastError,
  };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));
  app.use('/api', rateLimiter);

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'QuoteVerse API', timestamp: new Date().toISOString() });
  });

  app.get('/api/categories', (_req, res) => {
    const cacheKey = 'catalog:categories';
    let categories = getCached<ReturnType<typeof getCategoryCatalog>>(cacheKey);
    if (!categories) {
      categories = getCategoryCatalog();
      setCached(cacheKey, categories, 60 * 60_000);
    }
    res.json({ categories });
  });

  app.get('/api/categories/:categoryName/quotes', async (req, res) => {
    const categoryName = decodeURIComponent(req.params.categoryName);
    const localMatches = CURATED_QUOTES.filter(
      (q) => q.category.toLowerCase() === categoryName.toLowerCase()
    ).map((q) => ({
      ...q,
      id: buildCanonicalQuoteId(q.quoteText, q.author),
    }));
    res.json({ category: categoryName, quotes: localMatches });
  });

  app.get('/api/quotes/catalog', (req, res) => {
    const category = typeof req.query.category === 'string' ? req.query.category : '';
    const search = typeof req.query.search === 'string' ? req.query.search.toLowerCase() : '';
    const results = CURATED_QUOTES.filter((q) => {
      if (category && category !== 'All' && q.category.toLowerCase() !== category.toLowerCase()) {
        return false;
      }
      if (search) {
        return (
          q.quoteText.toLowerCase().includes(search) ||
          q.author.toLowerCase().includes(search) ||
          q.category.toLowerCase().includes(search)
        );
      }
      return true;
    }).map((q) => ({
      ...q,
      id: buildCanonicalQuoteId(q.quoteText, q.author),
    }));
    res.json({ quotes: results });
  });

  app.get('/api/quotes/daily', async (_req, res) => {
    const dayKey = new Date().toISOString().slice(0, 10);
    const cacheKey = `quote:daily:${dayKey}`;
    let daily = getCached<Quote>(cacheKey);
    if (!daily) {
      // Deterministic day index across curated quotes + try ZenQuotes/DummyJSON enrichment
      const dayNum = Math.floor(Date.now() / 86_400_000);
      const seed = CURATED_QUOTES[dayNum % CURATED_QUOTES.length];
      daily = {
        ...seed,
        id: buildCanonicalQuoteId(seed.quoteText, seed.author),
        source: 'Quote of the Day',
        createdAt: new Date().toISOString(),
      };
      setCached(cacheKey, daily, 12 * 60 * 60_000);
    }
    res.json({ quote: daily, date: dayKey });
  });

  app.get('/api/quotes/random', async (req, res) => {
    const category = typeof req.query.category === 'string' ? req.query.category : undefined;
    const providerParam = typeof req.query.provider === 'string' ? req.query.provider : 'auto';
    const provider: ApiProviderOption = ['auto', 'zenquotes', 'dummyjson', 'quotable', 'curated'].includes(
      providerParam
    )
      ? (providerParam as ApiProviderOption)
      : 'auto';
    const excludeParam = typeof req.query.exclude === 'string' ? req.query.exclude : '';
    const excludeIds = new Set(
      excludeParam
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
    );

    const result = await resolveQuote(provider, category, excludeIds);
    res.json(result);
  });

  // Gemini AI: Fast Mood-Based Recommendation (gemini-3.1-flash-lite)
  app.post('/api/ai/recommend', async (req, res) => {
    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        error: 'Gemini AI is unavailable because GEMINI_API_KEY is not configured in Secrets.',
      });
      return;
    }

    const mood = typeof req.body?.mood === 'string' ? req.body.mood.trim().slice(0, 40) : 'Motivated';
    const interest = typeof req.body?.interest === 'string' ? req.body.interest.trim().slice(0, 120) : '';

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: `Recommend one real, historically verified inspirational or philosophical quote suited for someone feeling "${mood}"${
          interest ? ` with an interest in "${interest}"` : ''
        }. Categorize it into one of: ${ALL_CATEGORIES.join(', ')}. Explain briefly why it resonates.`,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              quoteText: { type: Type.STRING, description: 'The verbatim quote text without surrounding quotation marks.' },
              author: { type: Type.STRING, description: 'The real historical or literary author.' },
              category: { type: Type.STRING, description: 'One category from the allowed QuoteVerse category list.' },
              whyItFits: { type: Type.STRING, description: 'One concise sentence connecting the quote to the user mood.' },
            },
            required: ['quoteText', 'author', 'category', 'whyItFits'],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim()) as {
        quoteText?: string;
        author?: string;
        category?: string;
        whyItFits?: string;
      };

      if (!parsed.quoteText || !parsed.author) {
        throw new Error('Gemini returned an incomplete recommendation.');
      }

      const cleanText = truncateForBlueprint(parsed.quoteText, 1000);
      const cleanAuthor = truncateForBlueprint(parsed.author, 160);
      const cleanCategory = ALL_CATEGORIES.includes(parsed.category || '')
        ? (parsed.category as string)
        : mapToCanonicalCategory('', cleanText);

      const quote: Quote = {
        id: buildCanonicalQuoteId(cleanText, cleanAuthor),
        quoteText: cleanText,
        author: cleanAuthor,
        category: cleanCategory,
        source: 'Gemini AI Recommender',
        externalApiId: `ai-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };

      res.json({ quote, whyItFits: parsed.whyItFits || '' });
    } catch (error) {
      console.error('Gemini recommend error:', error);
      res.status(502).json({
        error: error instanceof Error ? error.message : 'Failed to generate AI recommendation.',
      });
    }
  });

  // Gemini AI: Google Search Grounding for Author & Historical Context (gemini-4-hydrogen)
  app.post('/api/ai/ground', async (req, res) => {
    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        error: 'Gemini AI is unavailable because GEMINI_API_KEY is not configured in Secrets.',
      });
      return;
    }

    const quoteText = typeof req.body?.quoteText === 'string' ? req.body.quoteText.trim().slice(0, 600) : '';
    const author = typeof req.body?.author === 'string' ? req.body.author.trim().slice(0, 120) : '';

    if (!quoteText || !author) {
      res.status(400).json({ error: 'Both quoteText and author are required.' });
      return;
    }

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Verify the origin and historical context of this quote using Google Search:\nQuote: "${quoteText}"\nAttributed Author: ${author}\n\nProvide:\n1. A brief verification & meaning summary (2-3 sentences).\n2. Historical or literary context of the author/work (2 sentences).\n3. One thoughtful journaling reflection prompt for the reader.\nKeep the tone calm, scholarly, and concise.`,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      const rawText = response.text ?? '';
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
      const sources: GroundingSource[] = [];
      const seenUris = new Set<string>();
      for (const chunk of chunks) {
        const web = (chunk as { web?: { uri?: string; title?: string } }).web;
        if (web?.uri && !seenUris.has(web.uri)) {
          seenUris.add(web.uri);
          sources.push({
            title: web.title || web.uri,
            uri: web.uri,
          });
        }
      }

      res.json({
        summary: rawText,
        historicalContext: '',
        reflectionPrompt: '',
        sources,
      });
    } catch (error) {
      console.error('Gemini search grounding error:', error);
      res.status(502).json({
        error: error instanceof Error ? error.message : 'Failed to fetch Search Grounded context.',
      });
    }
  });

  // Gemini AI: Multi-turn Literary Sage Chatbot (gemini-4-hydrogen)
  app.post('/api/ai/chat', async (req, res) => {
    const ai = getGeminiClient();
    if (!ai) {
      res.status(503).json({
        error: 'Gemini AI is unavailable because GEMINI_API_KEY is not configured in Secrets.',
      });
      return;
    }

    const message = typeof req.body?.message === 'string' ? req.body.message.trim().slice(0, 1500) : '';
    const historyInput = Array.isArray(req.body?.history) ? req.body.history : [];
    const activeQuote = req.body?.activeQuote as { quoteText?: string; author?: string; category?: string } | undefined;

    if (!message) {
      res.status(400).json({ error: 'Message cannot be empty.' });
      return;
    }

    try {
      const chatHistory = historyInput
        .slice(-12)
        .filter((m: { role?: string; text?: string }) => m && typeof m.text === 'string' && m.text.trim())
        .map((m: { role?: string; text?: string }) => ({
          role: m.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: String(m.text).slice(0, 1500) }],
        }));

      const contextHint = activeQuote?.quoteText
        ? `\nThe user is currently viewing this quote: "${activeQuote.quoteText}" by ${activeQuote.author || 'Unknown'} (${activeQuote.category || 'General'}).`
        : '';

      const chat = ai.chats.create({
        model: 'gemini-4-hydrogen',
        history: chatHistory,
        config: {
          systemInstruction:
            `You are the QuoteVerse Literary Sage—a warm, erudite companion for philosophical reflection, quote interpretation, and personalized quote curation. Keep answers clear, grounded, and concise (under 180 words unless asked for deeper analysis). When recommending a quote, format it clearly as "Quote" — Author. Use Google Search when verifying attributions or historical facts.${contextHint}`,
          tools: [{ googleSearch: {} }],
        },
      });

      const response = await chat.sendMessage({ message });
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
      const sources: GroundingSource[] = [];
      const seenUris = new Set<string>();
      for (const chunk of chunks) {
        const web = (chunk as { web?: { uri?: string; title?: string } }).web;
        if (web?.uri && !seenUris.has(web.uri)) {
          seenUris.add(web.uri);
          sources.push({ title: web.title || web.uri, uri: web.uri });
        }
      }

      res.json({
        reply: response.text || 'I could not formulate a response at this moment.',
        sources,
      });
    } catch (error) {
      console.error('Gemini chat error:', error);
      res.status(502).json({
        error: error instanceof Error ? error.message : 'Failed to communicate with Gemini Literary Sage.',
      });
    }
  });

  // Google Tasks Proxy (Bearer OAuth access token from client)
  app.get('/api/workspace/tasks/lists', async (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Missing Google OAuth Bearer token.' });
      return;
    }

    try {
      const apiRes = await fetch('https://tasks.googleapis.com/tasks/v1/users/@me/lists', {
        headers: { Authorization: authHeader },
      });
      const data = await apiRes.json();
      if (!apiRes.ok) {
        res.status(apiRes.status).json({ error: data?.error?.message || 'Failed to fetch Google Task lists.' });
        return;
      }
      res.json(data);
    } catch (error) {
      res.status(502).json({ error: error instanceof Error ? error.message : 'Google Tasks request failed.' });
    }
  });

  app.post('/api/workspace/tasks', async (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Missing Google OAuth Bearer token.' });
      return;
    }

    const listId = typeof req.body?.listId === 'string' && req.body.listId.trim() ? req.body.listId.trim() : '@default';
    const title = typeof req.body?.title === 'string' ? req.body.title.trim().slice(0, 300) : '';
    const notes = typeof req.body?.notes === 'string' ? req.body.notes.trim().slice(0, 2000) : '';
    const due = typeof req.body?.due === 'string' && req.body.due ? req.body.due : undefined;

    if (!title) {
      res.status(400).json({ error: 'Task title is required.' });
      return;
    }

    try {
      const apiRes = await fetch(
        `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(listId)}/tasks`,
        {
          method: 'POST',
          headers: {
            Authorization: authHeader,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            title,
            notes,
            ...(due ? { due: new Date(`${due}T12:00:00.000Z`).toISOString() } : {}),
          }),
        }
      );
      const data = await apiRes.json();
      if (!apiRes.ok) {
        res.status(apiRes.status).json({ error: data?.error?.message || 'Failed to create Google Task.' });
        return;
      }
      res.json(data);
    } catch (error) {
      res.status(502).json({ error: error instanceof Error ? error.message : 'Google Tasks request failed.' });
    }
  });

  // Google Chat Proxy (Bearer OAuth access token from client)
  app.get('/api/workspace/chat/spaces', async (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Missing Google OAuth Bearer token.' });
      return;
    }

    try {
      const apiRes = await fetch('https://chat.googleapis.com/v1/spaces', {
        headers: { Authorization: authHeader },
      });
      const data = await apiRes.json();
      if (!apiRes.ok) {
        res.status(apiRes.status).json({
          error:
            data?.error?.message ||
            'Google Chat requires a Business or Enterprise Google Workspace account and a configured Chat app in Google Cloud Console.',
          statusCode: apiRes.status,
        });
        return;
      }
      res.json(data);
    } catch (error) {
      res.status(502).json({ error: error instanceof Error ? error.message : 'Google Chat request failed.' });
    }
  });

  app.post('/api/workspace/chat/messages', async (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Missing Google OAuth Bearer token.' });
      return;
    }

    const spaceName = typeof req.body?.spaceName === 'string' ? req.body.spaceName.trim() : '';
    const text = typeof req.body?.text === 'string' ? req.body.text.trim().slice(0, 2000) : '';

    if (!spaceName.startsWith('spaces/') || !text) {
      res.status(400).json({ error: 'Valid Google Chat spaceName and message text are required.' });
      return;
    }

    try {
      const apiRes = await fetch(`https://chat.googleapis.com/v1/${spaceName}/messages`, {
        method: 'POST',
        headers: {
          Authorization: authHeader,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text }),
      });
      const data = await apiRes.json();
      if (!apiRes.ok) {
        res.status(apiRes.status).json({
          error:
            data?.error?.message ||
            'Failed to send message to Google Chat. Ensure your Workspace account and Chat app configuration are active.',
        });
        return;
      }
      res.json(data);
    } catch (error) {
      res.status(502).json({ error: error instanceof Error ? error.message : 'Google Chat request failed.' });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`QuoteVerse server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start QuoteVerse server:', err);
  process.exit(1);
});
